// license:BSD-3-Clause
// copyright-holders:FIND
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class Jr2Format
// JR2�t�@�C���t�H�[�}�b�g�̑���S��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include <sys/stat.h>
#include "VJR200.h"
#include "Jr2Format.h"

Jr2Format::Jr2Format() : pointer(this)
{
	majVer = 1;
	minVer = 0;
}


Jr2Format::~Jr2Format()
{
	if (fp != nullptr)
		fclose(fp);

}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
bool Jr2Format::Init(const TCHAR * fn)
{
	_tcsncpy(fileName, fn, MAX_PATH);

	struct _stat buf;
	int st = _tstat(fileName, &buf);
	fileSize = buf.st_size;

	if (st != 0) {
		fp = _tfopen(fileName, _T("wb"));
		if (fp == nullptr)
			return false;
		fwrite(HEADER, sizeof(uint8_t), sizeof(HEADER) / sizeof(uint8_t), fp);
		fclose(fp);
		fp = nullptr;
	}

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �^�C�v�𕶎���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
const TCHAR * Jr2Format::GetType()
{
	return _T("JR2");
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C������Ԃ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
const TCHAR* Jr2Format::GetFileName()
{
	return fileName;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 1�o�C�g��������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::WriteByte(uint8_t b)
{
	bWriting = true;
	if (fp != nullptr) {
		fwrite(&b, sizeof(uint8_t), sizeof(uint8_t), fp);
		pointer.bytePointer = ftell(fp);
		pointer.bitPointer = 7;
		fileSize = pointer.bytePointer;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 1�r�b�g���̃��[�h�f�[�^��Ԃ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Jr2Format::GetLoadData()
{
	bCountStart = true;
	return lastBit;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CPU�̏���N���b�N���J�E���^��i�߂�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::TickCounter(int c)
{
	if (!bCountStart) return;

	counter += c;
	if (counter >= DATA_CYCLE) {
		counter = 0;
		pointer.Next();
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu���o�C�g���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t Jr2Format::GetPoiner()
{
	return pointer.bytePointer - DATA_BLOCK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu��b���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t Jr2Format::GetTimeCounter()
{
	uint32_t u = pointer.bytePointer - DATA_BLOCK;
	u = u * 1668 / 1000000;

	return u;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu��擪��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::Top()
{
	pointer.Top();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ���̃v���O�����̓��o��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::Next()
{
	uint32_t p1, p2, p3, fileSize;
	uint8_t d;
	int c = 0;
	bool bOpened = false;

	p1 = pointer.bytePointer;

	if (fp == nullptr) {
		fp = _tfopen(fileName, _T("rb"));
		bOpened = true;
	}
	if (fp == nullptr) {
#ifdef _WIN32
		MessageBox(g_hMainWnd, g_strTable[(int)Msg::Failed_to_open_the_file], NULL, 0);
#endif
		return;
	}
	struct _stat buf;
	_tstat(fileName, &buf);
	fileSize = buf.st_size;

	while (p1 != fileSize) {
		fseek(fp, p1, SEEK_SET);
		fread(&d, sizeof(uint8_t), 1, fp);
		if (d == 0xcc || d == 0) {
			do {
				++p1;
				fseek(fp, p1, SEEK_SET);
				fread(&d, sizeof(uint8_t), 1, fp);
			} while ((d == 0xcc || d == 0) && p1 < fileSize);
		}
		if (p1 >= fileSize) break;

		do {
			++p1;
			fseek(fp, p1, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
			if (d == 0xcc)
				++c;
			else
				c = 0;
		} while (c < 50 && p1 < fileSize);

		if (p1 >= fileSize) break;

		do {
			++p1;
			fseek(fp, p1, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
		} while ((d == 0xcc || d == 0) && p1 < fileSize);

		if (p1 >= fileSize) break;

		p2 = p1;
		do {
			--p1;
			fseek(fp, p1, SEEK_SET);
			fread(&d, 1, 1, fp);
		} while (p1 != 0 && d == 0xcc);
		++p1;
		if (p1 <= DATA_BLOCK) p1 = DATA_BLOCK;

		p3 = p2;
		p3 += 24;
		uint8_t a[12] = {};
		for (int i = 0; i < 12; ++i) {
			fseek(fp, p3 + i, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
			a[i] = d;
		}

		bool bCheckArray = true;
		for (int i = 0; i < 12; ++i) {
			if (a[i] != CHECK_ARRAY[i])
				bCheckArray = false;
		}

		if (bCheckArray) {
			pointer.bytePointer = p1;
			pointer.bitPointer = 8;
			if (bOpened) {
				fclose(fp);
				fp = nullptr;
			}
			return;
		}
	}

	pointer.bytePointer = fileSize - 1;
	if (bOpened) {
		fclose(fp);
		fp = nullptr;
	}
	return;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �ЂƂO�̃v���O�����̓��o��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::Prev()
{
	uint32_t p1, p2, p3 , fileSize;
	uint8_t d;
	int c = 0;
	bool bOpened = false;

	p1 = pointer.bytePointer;
	if (p1 <= DATA_BLOCK) {
		pointer.Top();
		return;
	}
	
	if (fp == nullptr) {
		fp = _tfopen(fileName, _T("rb"));
		bOpened = true;
	}
	if (fp == nullptr) {
#ifdef _WIN32
		MessageBox(g_hMainWnd, g_strTable[(int)Msg::Failed_to_open_the_file], NULL, 0);
#endif
		return;
	}
	struct _stat buf;
	_tstat(fileName, &buf);
	fileSize = buf.st_size;

	while (p1 != 0) {
		do {
			--p1;
			fseek(fp, p1, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
			if (d == 0xcc)
				++c;
			else
				c = 0;
		} while (p1 != 0 && c < 50);

		if (p1 == 0) break;

		do {
			--p1;
			fseek(fp, p1, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
		} while (p1 != 0 && d == 0xcc);

		if (p1 == 0) break;
		++p1;
		p2 = p1;
		do {
			++p2;
			fseek(fp, p2, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
		} while (p2 != fileSize && d == 0xcc);

		if (p2 == fileSize) {
			pointer.bytePointer = p1;
			pointer.bitPointer = 8;
			if (bOpened) {
				fclose(fp);
				fp = nullptr;
			}
			return;
		}

		p3 = p2;
		p3 += 24;
		uint8_t a[12] = {};
		for (int i = 0; i < 12; ++i) {
			fseek(fp, p3 + i, SEEK_SET);
			fread(&d, sizeof(uint8_t), 1, fp);
			a[i] = d;
		}

		bool bCheckArray = true;
		for (int i = 0; i < 12; ++i) {
			if (a[i] != CHECK_ARRAY[i])
				bCheckArray = false;
		}

		if (bCheckArray) {
			pointer.bytePointer = p1;
			pointer.bitPointer = 8;
			if (bOpened) {
				fclose(fp);
				fp = nullptr;
			}
			return;
		}
	}
	pointer.Top();
	if (bOpened) {
		fclose(fp);
		fp = nullptr;
	}
	return;
}

void Jr2Format::FF()
{
}

void Jr2Format::Rew()
{
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �����[�g�[�q���^���E�Đ��ɂȂ������̏���
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::remoteOn()
{
	if (fp == nullptr)	
		fp = _tfopen(fileName, _T("a+b"));
	if (fp == nullptr) {
#ifdef _WIN32
		MessageBox(g_hMainWnd, g_strTable[(int)Msg::Failed_to_open_the_file], NULL, 0);
#endif
		return;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �����[�g�[�q����~�ɂȂ������̏���
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Jr2Format::remoteOff()
{
	if (fp != nullptr) {
		if (bWriting && g_bCmtAddBlank) {
			uint8_t b = 0;
			for (int i = 0; i < BLANK_LENGTH; ++i)
				fwrite(&b, sizeof(uint8_t), sizeof(uint8_t), fp);
			bWriting = false;
		}
		fclose(fp);
		fp = nullptr;
	}
	bCountStart = false;
}


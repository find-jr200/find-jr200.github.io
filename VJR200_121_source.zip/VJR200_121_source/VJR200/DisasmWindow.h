// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __DISASMWINDOW_H__
#define __DISASMWINDOW_H__
#include <d2d1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#include <wincodec.h>
#include <cstdint>
#include <string>
#include <vector>

using namespace std;

LRESULT CALLBACK WndProcDisasmWindow(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

struct OperationSet
{
	int startAddress; // �I�y���[�V�������X�^�[�g����A�h���X
	wchar_t bytesString[11]; // �I�y�R�[�h�{�I�y�����h���X�y�[�X�ŋ�؂���������
	uint8_t byteArray[20]; // �I�y�R�[�h�{�I�y�����h�̔z��
	wchar_t nimonic[10]; // �j�[���j�b�N
	wchar_t operand[20]; // �I�y�����h
};


class DisasmWindow
{
public:
	DisasmWindow();
	~DisasmWindow();
	HRESULT Init();
	HWND GetHWnd();
	void Show();
	HRESULT OnRender();
	void OnResize(
		UINT width,
		UINT height
	);
	void Close();

protected:
	HWND hwnd;
	IWICImagingFactory *pWICFactory;
	ID2D1HwndRenderTarget *pRenderTarget;
	IDWriteTextFormat *pTextFormat;
	ID2D1SolidColorBrush *pBlackBrush;
	IDWriteTextLayout* pTextLayout;

	HRESULT CreateDeviceIndependentResources();
	HRESULT CreateDeviceResources();
	void DiscardDeviceResources();

	void SetOperation(OperationSet* oSet);
	void MakeOperand(wchar_t* s, vector<uint8_t>& ops, int amode, int bytes);

	uint16_t curAddress, startAddress;


	const wchar_t *const nimonic[256] = { 
		L"NA",L"NOP",L"NA",L"NA",L"NA",L"NA",L"TAP",L"TPA",L"INX",L"DEX",L"CLV",L"SEV",L"CLC",L"SEC",L"CLI",L"SEI",
		L"SBA",L"CBA",L"NA",L"NA",L"NA",L"NA",L"TAB",L"TBA",L"NA",L"DAA",L"NA",L"ABA",L"NA",L"NA",L"NA",L"NA",
		L"BRA",L"NA",L"BHI",L"BLS",L"BCC",L"BCS",L"BNE",L"BEQ",L"BVC",L"BVS",L"BPL",L"BMI",L"BGE",L"BLT",L"BGT",L"BLE",
		L"TSX",L"INS",L"PULA",L"PULB",L"DES",L"TXS",L"PSHA",L"PSHB",L"NA",L"RTS",L"NA",L"RTI",L"NA",L"NA",L"WAI",L"SWI",
		L"NEGA",L"NA",L"NA(COMA)",L"COMA",L"LSRA",L"NA",L"RORA",L"ASRA",L"ASLA",L"ROLA",L"DECA",L"NA(DECA)",L"INCA",L"TSTA",L"NA",L"CLRA",
		L"NEGB",L"NA",L"NA(COMB)",L"COMB",L"LSRB",L"NA",L"RORB",L"ASRB",L"ASLB",L"ROLB",L"DECB",L"NA(DECB)",L"INCB",L"TSTB",L"NA",L"CLRB",
		L"NEG",L"NA(NEG)",L"NA(COM)",L"COM",L"LSR",L"NA(LSR)",L"ROR",L"ASR",L"ASL",L"ROL",L"DEC",L"NA(DEC)",L"INC",L"TST",L"JMP",L"CLR",
		L"NEG",L"NA(NEG)",L"NA(COM)",L"COM",L"LSR",L"NA(LSR)",L"ROR",L"ASR",L"ASL",L"ROL",L"DEC",L"NA(DEC)",L"INC",L"TST",L"JMP",L"CLR",
		L"SUBA",L"CMPA",L"SBCA",L"NA(SBCA)",L"ANDA",L"BITA",L"LDAA",L"NA",L"EORA",L"ADCA",L"ORAA",L"ADDA",L"CPX",L"BSR",L"LDS",L"NA",
		L"SUBA",L"CMPA",L"SBCA",L"NA(SBCA)",L"ANDA",L"BITA",L"LDAA",L"STAA",L"EORA",L"ADCA",L"ORAA",L"ADDA",L"CPX",L"NA",L"LDS",L"STS",
		L"SUBA",L"CMPA",L"SBCA",L"NA(SBCA)",L"ANDA",L"BITA",L"LDAA",L"STAA",L"EORA",L"ADCA",L"ORAA",L"ADDA",L"CPX",L"JSR",L"LDS",L"STS",
		L"SUBA",L"CMPA",L"SBCA",L"NA(SBCA)",L"ANDA",L"BITA",L"LDAA",L"STAA",L"EORA",L"ADCA",L"ORAA",L"ADDA",L"CPX",L"JSR",L"LDS",L"STS",
		L"SUBB",L"CMPB",L"SBCB",L"NA(SBCB)",L"ANDB",L"BITB",L"LDAB",L"NA",L"EORB",L"ADCB",L"ORAB",L"ADDB",L"NA",L"NA",L"LDX",L"NA",
		L"SUBB",L"CMPB",L"SBCB",L"NA(SBCB)",L"ANDB",L"BITB",L"LDAB",L"STAB",L"EORB",L"ADCB",L"ORAB",L"ADDB",L"NA",L"NA",L"LDX",L"STX",
		L"SUBB",L"CMPB",L"SBCB",L"NA(SBCB)",L"ANDB",L"BITB",L"LDAB",L"STAB",L"EORB",L"ADCB",L"ORAB",L"ADDB",L"NA",L"NA",L"LDX",L"STX",
		L"SUBB",L"CMPB",L"SBCB",L"NA(SBCB)",L"ANDB",L"BITB",L"LDAB",L"STAB",L"EORB",L"ADCB",L"ORAB",L"ADDB",L"NA",L"NA",L"LDX",L"STX" };

	const int bytes[256] = { 
		1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		2,1,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
		2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		2,2,2,2,2,2,2,1,2,2,2,2,3,2,3,1,
		2,2,2,2,2,2,2,2,2,2,2,2,2,1,2,2,
		2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		2,2,2,2,2,2,2,1,2,2,2,2,1,1,3,1,
		2,2,2,2,2,2,2,2,2,2,2,2,1,1,2,2,
		2,2,2,2,2,2,2,2,2,2,2,2,1,1,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,1,1,3,3};

	const int addressing[256] = { 
		0,4,0,0,0,0,4,4,4,4,4,4,4,4,4,4,
		4,4,0,0,0,0,4,4,0,4,0,4,0,0,0,0,
		5,0,5,5,5,5,5,5,5,5,5,5,5,5,5,5,
		4,4,4,4,4,4,4,4,0,4,0,4,0,0,4,4,
		4,0,4,4,4,0,4,4,4,4,4,4,4,4,0,4,
		4,0,4,4,4,0,4,4,4,4,4,4,4,4,0,4,
		2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		0,0,0,0,0,0,0,0,0,0,0,0,0,5,0,0,
		1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,1,
		2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
		1,1,1,1,1,1,1,1,1,1,1,1,0,0,1,1,
		2,2,2,2,2,2,2,2,2,2,2,2,0,0,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,0,0,3,3};
};

#endif
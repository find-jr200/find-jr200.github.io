// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __MEMWINDOW_H__
#define __MEMWINDOW_H__
#include <d2d1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#include <wincodec.h>

#pragma comment(lib, "dwrite.lib")

LRESULT CALLBACK WndProcMemWindow(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

class MemWindow
{
public:
	MemWindow();
	~MemWindow();
	HRESULT Init();
	HWND GetHWnd();
	void Show();
	HRESULT OnRender();
	void OnResize(
		UINT width,
		UINT height
	);
	void Close();

protected:
	HWND hwnd;
	ID2D1Factory *pD2DFactory;
	IWICImagingFactory *pWICFactory;
	IDWriteFactory *pDWriteFactory;
	ID2D1HwndRenderTarget *pRenderTarget;
	IDWriteTextFormat *pTextFormat;
	ID2D1SolidColorBrush *pBlackBrush;
	IDWriteTextLayout* pTextLayout;

	HRESULT CreateDeviceIndependentResources();
	HRESULT CreateDeviceResources();
	void DiscardDeviceResources();
};

#endif
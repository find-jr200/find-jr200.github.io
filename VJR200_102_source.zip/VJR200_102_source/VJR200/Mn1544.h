// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __MN1544_H__
#define __MN1544_H__
#include <cstdint>

enum class InputType {ANK, KANA, GRAPH};

class Mn1544
{
public:
	Mn1544();
	~Mn1544();
	void SetKeyState(uint8_t reg);
	bool Init();
	uint8_t KeyIn(int w);
	uint8_t KeyScan();
	uint8_t ConvertKeyCode(int w);
protected:
	static const int FONTSIZE = 2048;
	void ScanKeyAndPad();
	uint8_t buff[FONTSIZE + 1];
	uint8_t scanBuff[3];
	int pointer = 0;
	bool joystick1 = false;
	bool joystick2 = false;
	InputType mode = InputType::ANK;
	bool bInitialized = false;
	bool bScaned = false;
	bool bScanning = false;
	bool bKtested = false;
	bool bBreakOn = true;
	uint8_t repeatCode = 0;
	uint8_t lastKeyIn = 0;
	int repeatWait = 0;

	uint8_t preKtest = 0;
	uint8_t preKack = 0;
	uint8_t prepreKtest = 0;
	uint8_t prepreKack = 0;
};

#endif
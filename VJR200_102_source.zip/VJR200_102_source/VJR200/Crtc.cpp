// license:BSD-3-Clause
// copyright-holders:FIND
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class Crtc
// CRT�R���g���[���@Dicrect2D�f�o�C�X���쐬���`��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#ifdef _WIN32
#include "Commdlg.h"
#endif
#include "JRSystem.h"
#include "Crtc.h"
#include "VJR200.h"

extern JRSystem sys;

Crtc::Crtc()
{}

Crtc::~Crtc()
{
#ifdef _WIN32
	delete[] pixelData;
	DiscardDeviceResources();
	SafeRelease(&pD2dFactory);
	SafeRelease(&pDWriteFactory);
	SafeRelease(&pTextFormatR);
	SafeRelease(&pTextFormatL);
#endif
}

#ifdef _WIN32
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �f�o�C�X�Ɨ����\�[�X����
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
HRESULT Crtc::CreateDeviceIndependentResources()
{
	static const wchar_t msc_fontName[] = L"Verdana";
	static const FLOAT msc_fontSize = 12;
	HRESULT hr;

	// Create a Direct2D factory.
	hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &pD2dFactory);

	if (SUCCEEDED(hr))
	{
		// Create a DirectWrite factory.
		hr = DWriteCreateFactory(
			DWRITE_FACTORY_TYPE_SHARED,
			__uuidof(pDWriteFactory),
			reinterpret_cast<IUnknown **>(&pDWriteFactory)
		);
	}
	if (SUCCEEDED(hr))
	{
		// Create a DirectWrite text format object.
		hr = pDWriteFactory->CreateTextFormat(
			msc_fontName,
			NULL,
			DWRITE_FONT_WEIGHT_NORMAL,
			DWRITE_FONT_STYLE_NORMAL,
			DWRITE_FONT_STRETCH_NORMAL,
			msc_fontSize,
			L"", //locale
			&pTextFormatL
		);
	}

	if (SUCCEEDED(hr))
	{
		// Create a DirectWrite text format object.
		hr = pDWriteFactory->CreateTextFormat(
			msc_fontName,
			NULL,
			DWRITE_FONT_WEIGHT_NORMAL,
			DWRITE_FONT_STYLE_NORMAL,
			DWRITE_FONT_STRETCH_NORMAL,
			msc_fontSize,
			L"", //locale
			&pTextFormatR
		);
	}

	if (SUCCEEDED(hr))
	{
		// Center the text horizontally and vertically.
		pTextFormatL->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
		pTextFormatL->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
	}

	if (SUCCEEDED(hr))
	{
		// Center the text horizontally and vertically.
		pTextFormatR->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_TRAILING);
		pTextFormatR->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_CENTER);
	}
	return hr;
}
#endif



////////////////////////////////////////////////////////////////////////////////////////////////////
//
//�@	������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
bool Crtc::Init()
{
#ifdef _WIN32
	// Direct2D������
	HRESULT hr;
	hr = CreateDeviceIndependentResources();
	if (FAILED(hr))
		return false;

	//ARGB
	JrColor[0] = 0xff000000; // black
	JrColor[1] = 0xff0000ff; // blue
	JrColor[2] = 0xffff0000; // red
	JrColor[3] = 0xffff00ff; // magenta
	JrColor[4] = 0xff00ff00; // green
	JrColor[5] = 0xff00ffff; // cyan
	JrColor[6] = 0xffffff00; // yellow
	JrColor[7] = 0xffffffff; // white
#else // Android
	JrColor[0] = 0xff000000; // black
	JrColor[1] = 0xffff0000; // blue
	JrColor[2] = 0xff0000ff; // red
	JrColor[3] = 0xffff00ff; // magenta
	JrColor[4] = 0xff00ff00; // green
	JrColor[5] = 0xffffff00; // cyan
	JrColor[6] = 0xff00ffff; // yellow
	JrColor[7] = 0xffffffff; // white
#endif
	pixelData = new uint32_t[BITMAP_H * BITMAP_W];
	if (pixelData == nullptr) 
		return false;

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
//�@	�ǂݏo��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t Crtc::Read(int r)
{
	return getVal;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
//�@	��������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Crtc::Write(int r, uint8_t b)
{
	borderColor =  7 & b;
}

#ifdef _WIN32
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Direct2D�f�o�C�X�쐬
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
HRESULT Crtc::CreateDeviceResources()
{
	HRESULT hr = S_OK;

	if (!pHwndRT)
	{
		RECT rc;
		GetClientRect(g_hMainWnd, &rc);

		D2D1_SIZE_U size = D2D1::SizeU(
			rc.right - rc.left,
			rc.bottom - rc.top
		);

		// Create a Direct2D render target.
		hr = pD2dFactory->CreateHwndRenderTarget(
			D2D1::RenderTargetProperties(),
			D2D1::HwndRenderTargetProperties(g_hMainWnd, size),
			&pHwndRT
		);

		ZeroMemory(pixelData, sizeof(uint32_t)* BITMAP_W*BITMAP_H);

		if (SUCCEEDED(hr))
		{
			D2D1_SIZE_U size = D2D1::SizeU(BITMAP_W, BITMAP_H);
			D2D1_PIXEL_FORMAT f = D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE);
			hr = pHwndRT->CreateBitmap(size, pixelData, BITMAP_W * sizeof(uint32_t), D2D1::BitmapProperties(f), &pBitmap);
		
			// Create a black brush.
			hr = pHwndRT->CreateSolidColorBrush(
				D2D1::ColorF(D2D1::ColorF::LightGray),
				&pGrayBrush
			);
			hr = pHwndRT->CreateSolidColorBrush(
				D2D1::ColorF(D2D1::ColorF::Black),
				&pBlackBrush
			);
		}
	}

	return hr;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �f�o�C�X���\�[�X�폜
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Crtc::DiscardDeviceResources()
{
	SafeRelease(&pHwndRT);
	SafeRelease(&pBitmap);
	SafeRelease(&pGrayBrush);
	SafeRelease(&pBlackBrush);
}
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �E�B���h�E�T�C�Y�ύX
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Crtc::Resize(bool bParamFullScreen)
{
#ifdef _WIN32
	DiscardDeviceResources();
#endif
	bFullScreen = bParamFullScreen;
}

#ifdef _WIN32
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Direct2D�`��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
HRESULT Crtc::OnRender()
{
	HRESULT hr = S_OK;
	hr = CreateDeviceResources();
	if (SUCCEEDED(hr))
	{
		pHwndRT->BeginDraw();
		pHwndRT->SetTransform(D2D1::Matrix3x2F::Identity());
		pHwndRT->Clear(D2D1::ColorF(D2D1::ColorF::Black));

		SetPixelData(); // ������JR-200�̕\���쐬
		hr = pBitmap->CopyFromMemory(NULL, pixelData, BITMAP_W * sizeof(uint32_t));

		D2D1_SIZE_F rtSize = pHwndRT->GetSize();
		D2D1_RECT_F dst;

		if (bFullScreen)
		{
			int dspW = GetSystemMetrics(SM_CXVIRTUALSCREEN);
			int dspH = GetSystemMetrics(SM_CYVIRTUALSCREEN);
			float jrAspect = (float)BITMAP_W / BITMAP_H;
			float dspAspect = (float)dspW / dspH;
			if (dspAspect > jrAspect)
			{
				// ����
				rtSize.height = (float)dspH;
				if (g_bSquarePixel)
					rtSize.width = dspH * jrAspect;
				else
					rtSize.width = dspH * jrAspect * REAL_WRATIO;
				float offset = (dspW - rtSize.width) / (float)2;
				dst = D2D1::RectF(offset, 0, rtSize.width + offset, rtSize.height);
			}
			else {
				// �c��
				if (g_bSquarePixel)
					rtSize.height = dspW / jrAspect;
				else
					rtSize.height = dspW / jrAspect * REAL_WRATIO;
				rtSize.width = (float)dspW;
				float offset = (dspH - rtSize.height) / (float)2;
				dst = D2D1::RectF(0, offset, rtSize.width, rtSize.height + offset);
			}
		}
		else {
			dst = D2D1::RectF(0, 0, rtSize.width, rtSize.height - STATUSBAR_HEIGHT);
		}

		if (g_bSmoothing) {
			pHwndRT->DrawBitmap(pBitmap, &dst, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR, NULL);
		}
		else {
			pHwndRT->DrawBitmap(pBitmap, &dst, 1.0f, D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR, NULL);
		}

		if (!bFullScreen && STATUSBAR_HEIGHT != 0)
		{
			RECT rect;
			GetClientRect(g_hMainWnd, &rect);

			D2D1_RECT_F statusBarRect = D2D1::RectF(0, rtSize.height - STATUSBAR_HEIGHT, rtSize.width, rtSize.height);
			D2D1_RECT_F fileNameRect = D2D1::RectF(0, rtSize.height - STATUSBAR_HEIGHT, rtSize.width - COUNTER_WIDTH - CMTSTAT_WIDTH, rtSize.height);
			D2D1_RECT_F counterRect = D2D1::RectF(rtSize.width - COUNTER_WIDTH, rtSize.height - STATUSBAR_HEIGHT, rtSize.width, rtSize.height);
			D2D1_RECT_F cmtRect = D2D1::RectF(rtSize.width - COUNTER_WIDTH - CMTSTAT_WIDTH, rtSize.height - STATUSBAR_HEIGHT, rtSize.width - COUNTER_WIDTH, rtSize.height);

			pHwndRT->FillRectangle(statusBarRect, pGrayBrush);
			wchar_t buf[MAX_PATH] = {};
			if (g_pTapeFormat != nullptr)
				GetFileTitle(g_pTapeFormat->GetFileName(), buf, MAX_PATH);

			// �t�@�C����
			pHwndRT->DrawText(
				buf,
				_tcslen(buf),
				pTextFormatL,
				fileNameRect,
				pBlackBrush
			);

			if (g_pTapeFormat != nullptr) {
				// �^�C���J�E���^
				uint32_t u = g_pTapeFormat->GetTimeCounter();
				unsigned int min = u / 60;
				u -= min * 60;
				wsprintf(buf, _T("%u:%#02u"), min, u);
				//wsprintf(buf, _T("%u"), g_pTapeFormat->GetPoiner());
				pHwndRT->DrawText(
					buf,
					_tcslen(buf),
					pTextFormatR,
					counterRect,
					pBlackBrush
				);
				
				// CMT�X�e�[�^�X
				wsprintf(buf, _T("%s:%s%s"), sys.pMn1271->GetRemoteStatus() ? _T("ON") : _T("OFF"),
					sys.pMn1271->GetReadStatus() ? _T("R") : _T(" "),
					sys.pMn1271->GetWriteStatus() ? _T("W") : _T(" "));
				pHwndRT->DrawText(
					buf,
					_tcslen(buf),
					pTextFormatR,
					cmtRect,
					pBlackBrush
				);
			}
		}

		hr = pHwndRT->EndDraw();

		if (hr == D2DERR_RECREATE_TARGET)
		{
			hr = S_OK;
			DiscardDeviceResources();
		}
	}

	return hr;
}
#else // Android
void Crtc::OnRender(uint32_t*  s)
{
	pixelData = s;
	SetPixelData();
}
#endif

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �ǂݏo���l�ݒ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Crtc::TickCounter(int cycles)
{
	g_vcyncCounter += cycles;
	int offset = (int)(2 * g_vcyncCounter / 3.f);
	if (offset > 767) 
		getVal = 255;
	else
		getVal = sys.pAddress->ReadByte(AVRAM + offset);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// JR-200�`��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void Crtc::SetPixelData()
{
	for (int i = 0; i < BITMAP_H * BITMAP_W; ++i)
		pixelData[i] = JrColor[borderColor];

	for (int x = 0; x < 32; ++x) {
		for (int y = 0; y < 24; ++y) {
			uint8_t c = sys.pAddress->ReadByte(TVRAM + x + (y * 32));
			uint8_t a = sys.pAddress->ReadByte(AVRAM + x + (y * 32));
			
			int mode = a & 0xc0;
			a &= 0x3f;
			switch (mode)
			{
			case 0: // Normal Character
			{
				int fColor = 7 & a;
				int bColor = (a & 0x38) >> 3;
				for (int i = 0; i < 8; ++i) {
					uint8_t fontFace = sys.pAddress->ReadByte(FRAM + c * 8 + i);
					for (int j = 0; j < 8; ++j) {
						int k = fontFace & (0x80 >> j);
						if (k == 0)
							pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + (i * 320)] = JrColor[bColor];
						else
							pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + (i * 320)] = JrColor[fColor];
					}
				}
				break;
			}
			case 0x40: // User Character
			{
				int fColor = 7 & a;
				int bColor = (a & 0x38) >> 3;

				for (int i = 0; i < 8; ++i) {
					uint8_t fontFace = sys.pAddress->ReadByte(PCGRAM1 + c * 8 + i);
					for (int j = 0; j < 8; ++j) {
						int k = fontFace & (0x80 >> j);
						if (k == 0)
							pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + (i * 320)] = JrColor[bColor];
						else
							pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + (i * 320)] = JrColor[fColor];
					}
				}
				break;
			}
			case 0x80: // Semi Graphics
			case 0xc0:
			{
				uint8_t semigra[4];
				semigra[0] = (c & 0x38) >> 3; // �E��
				semigra[1] = c & 0x07; // ����
				semigra[2] = (a & 0x38) >> 3; // �E��
				semigra[3] = a & 0x07; // ����
				for (int i = 0; i < 4; ++i) {
					for (int j = 0; j < 4; ++j) {
						pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + (i * 320)] = JrColor[semigra[1]];
						pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + 4 + (i * 320)] = JrColor[semigra[0]];
						pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + ((i + 4) * 320)] = JrColor[semigra[3]];
						pixelData[(x * 8 + 32) + ((y * 8 + 16) * 320) + j + 4 + ((i + 4) * 320)] = JrColor[semigra[2]];
					}
				}
				break;
			}
			}
		}
	}
}

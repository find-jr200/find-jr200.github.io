// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __ADDRESS_H__
#define __ADDRESS_H__
#ifndef _WIN32
#include "stdafx.h"
#endif
#include "cstdint"

enum class DevType { None, Rom, Ram, Mn1271, Crtc };

class Address
{
public:
	Address();
	~Address();

	bool Init();
	uint8_t ReadByte(uint16_t address);
	uint8_t ReadByteForDebug(uint16_t address);
	void WriteByte(uint16_t address, uint8_t b);
	void SaveDumpFile();
	bool CjrQuickLoad(const TCHAR* filename);
	BOOL LoadRomFile();

protected:
	DevType* attribute;
	uint8_t* memory;
};
#endif
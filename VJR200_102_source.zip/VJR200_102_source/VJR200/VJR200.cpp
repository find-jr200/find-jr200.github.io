// license:BSD-3-Clause
// copyright-holders:FIND
// VJR200.cpp : �A�v���P�[�V�����̃G���g�� �|�C���g���`���܂��B
//
#include "stdafx.h"
#include <WindowsX.h>
#include <VersionHelpers.h>
#include <Commdlg.h>
#include <commctrl.h>
#include <shlwapi.h>
#include "JRSystem.h"
#include "VJR200.h"
#include "CjrFormat.h"
#include "AppSetting.h"
#include "OptionDialog.h"
#include "Jr2Format.h"

#pragma comment(lib, "imm32.lib")

// �萔
#define MAX_LOADSTRING 100
const int CLOCK = 1339285;
const int BITMAP_W = 320;
const int BITMAP_H = 224;
const float REAL_WRATIO = 0.85f;
const int STR_RESOURCE_NUM = 38;
const unsigned int RECENT_FILES_NUM = 10;
const int STATUSBAR_HEIGHT = 20;
const int SUBMENU_POS = 14;
const int CJR_FILE_MAX = 65536;
const int CPU_SPEED_MAX = 1000;

// �O���[�o���ϐ�:
HINSTANCE g_hInst;
HWND g_hMainWnd;
HWND g_hMemWnd;
HMODULE g_hMod; // ���\�[�XDLL�̃��W���[���n���h��
HIMC g_hImc;

int g_dramWait = 0;
bool g_deviceRunning = true;
int g_debug = -1; // -1 = �ʏ���s�@�@1 = �X�e�b�v���s�@�@0 = ��~
int g_breakPoint = -1;
bool g_bSoundOn = false;
bool g_bMemWindow = false;
bool g_bDisasmWindow = false;
MemWindow* g_pMemWindow = nullptr;
DisasmWindow* g_pDisasmWindow = nullptr;
HANDLE g_hEvent[3][6];
//HANDLE bufWriteEvent[3];

TCHAR g_stringTable[STR_RESOURCE_NUM + 1][256]; // [0]�͎g��Ȃ�
// �O���t�L�[�{�[�h�p�e�[�u��
uint8_t g_gcharCode1[][14] = { { 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89, 0,    0xed, 0x8c, 0x8e, 0 },
                               { 0x98, 0x9b, 0x99, 0xec, 0xeb, 0x9a, 0xe9, 0x90, 0x8d, 0xe0, 0xea, 0,    0,    0 },
                               { 0x91, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0xef, 0xf0, 0,    0,    0,    0,    0 },
                               { 0xfa, 0xf8, 0xe3, 0xf6, 0xe2, 0xee, 0x8a, 0,    0,    0,    0,    0,    0,    0 } };
uint8_t g_gcharCode2[][14] = { { 0x9e, 0xff, 0x9f, 0x9c, 0x8f, 0   , 0,    0xfe, 0x9d, 0xfc, 0,    0,    0,    0 },
                               { 0xf1, 0xf7, 0xe5, 0xf2, 0xf4, 0xf9, 0xf5, 0xfb, 0xfd, 0,    0,    0,    0,    0 },
                               { 0xe1, 0xf3, 0xe4, 0xe6, 0xe7, 0xe8, 0x8b, 0,    0,    0,    0,    0,    0,    0 } };
BYTE g_bits1[448], g_bits2[336]; // �O���t�L�[�{�[�h�p�r�b�g�}�b�v�f�[�^
bool g_bForcedJoystick = false;
int g_vcyncCounter = 0;
ITapeFormat* g_pTapeFormat;

JRSystem sys;

// �_�C�A���O�Eini�ۑ�����
int g_cpuScale = 100;
int g_viewScale = 2;
bool g_bSmoothing = false;
bool g_bFpsCpu = false;
int g_soundVolume =40;
bool g_bRamExpand1 = false;
bool g_bRamExpand2 = false;
RECT g_windowPos = {100, 100, 0, 0};
int g_refRate = 60;
bool g_bRefRateAuto = true;
bool g_bSquarePixel = true;
bool g_bOverClockLoad = false;
int g_quickTypeS = 30;
int g_language = 0;
int g_stereo1 = 5, g_stereo2 = 5, g_stereo3 = 5;
int g_prOutput = 0;
int g_prMaker = 0;
deque<wstring> g_rFilesforCJRSet;
deque<wstring> g_rFilesforQLoad;
TCHAR g_pRomFile[MAX_PATH];
TCHAR g_pFontFile[MAX_PATH];
bool g_b2buttons = false;
int g_Joypad1pA = 0, g_Joypad1pB = 0, g_Joypad2pA = 0, g_Joypad2pB = 0;
int g_forcedJoypadA = 0x20, g_forcedJoypadB = 0x20;
int g_sBufferWriteInterval = 60;
int g_bCmtAddBlank = 1;

static TCHAR szTitle[MAX_LOADSTRING];                  // �^�C�g�� �o�[�̃e�L�X�g
static TCHAR szWindowClass[MAX_LOADSTRING];            // ���C�� �E�B���h�E �N���X��
static HANDLE hFpsTimer = NULL;
static HANDLE hQuickTypeTimer = NULL;
static HANDLE hTimerQueue = NULL;
static int fps = 0;
static bool bFullScreen = false;
static HWND hWndDebug;
static bool bDebugWindow = false;
static HWND hWndVGraphKeyb;
static bool bVGraphKeyb = false;
static TCHAR tmpFileName[MAX_PATH];
static int quickTypeCount;
static int quickTYpeDataSize;
static uint8_t* quickTypeData = nullptr;
static bool bQuickTyping = false;
static int preCpuScale;
static HANDLE hSoundThread0 = NULL, hSoundThread1 = NULL, hSoundThread2 = NULL;
static uint8_t ioReg[32];

static AppSetting setting;

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �G���g���E�|�C���g
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ LPWSTR    lpCmdLine,
	_In_ int       nCmdShow)
{
	UNREFERENCED_PARAMETER(hPrevInstance);
	UNREFERENCED_PARAMETER(lpCmdLine);

	// TODO: �����ɃR�[�h��}�����Ă��������B
	if (!setting.Init()) {
		MessageBox(NULL, _T("Failed to create application settings\r\nSettings will not be saved"), NULL, 0);
	}

	LCID id = GetUserDefaultLCID();

	if (g_language == 0) {
		if (id == 1041) {
			g_hMod = LoadLibrary(_T(".\\VJR200_jp.dll"));
		}
		else {
			g_hMod = LoadLibrary(_T(".\\VJR200_en.dll"));
		}
	}
	else if (g_language == 1) {
		g_hMod = LoadLibrary(_T(".\\VJR200_jp.dll"));
	}
	else {
		g_hMod = LoadLibrary(_T(".\\VJR200_en.dll"));
	}

	if (g_hMod == NULL) {
		MessageBox(NULL, _T("Failed to load resource DLL"), NULL, MB_OK);
		return 0;
	}

	for (int i = 1; i < STR_RESOURCE_NUM + 1; ++i)
		LoadString(g_hMod, i + 2000, g_stringTable[i], 256);

	if (!IsWindowsVistaSP2OrGreater()) {
		MessageBox(NULL, g_stringTable[1], NULL, 0);
		return 0;
	}

	CoInitialize(NULL);
	hTimerQueue = CreateTimerQueue();
	timeBeginPeriod(1);
	//ImmDisableIME(-1);

	// �O���[�o������������������Ă��܂��B
	LoadString(g_hMod, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
	LoadString(g_hMod, IDC_VJR200, szWindowClass, MAX_LOADSTRING);
	MyRegisterClass(hInstance);

	// �A�v���P�[�V�����̏����������s���܂�:
	if (!InitInstance(hInstance, nCmdShow))
	{
		return FALSE;
	}

	g_hImc = ImmAssociateContext(g_hMainWnd, 0);

	HACCEL hAccelTable = LoadAccelerators(g_hInst, MAKEINTRESOURCE(IDC_VJR200));
	int i;
	if (i = sys.Init()) {
		TCHAR c[30];
		wsprintf(c, g_stringTable[3], i);
		MessageBox(g_hMainWnd, c, NULL, 0);
		return FALSE;
	}

	if (g_deviceRunning) {
		ValidateRect(g_hMainWnd, NULL);
		SetClassLong(g_hMainWnd, GCL_HBRBACKGROUND, (LONG)CreateSolidBrush(RGB(0, 0, 0)));
		sys.Start();
		sys.Reset();
	}
	else {
		InvalidateRect(g_hMainWnd, NULL, TRUE);
	}

	if (g_bRefRateAuto) {
		int r = GetRefreshRate();
		if (r == 0 || r == 1)
			g_refRate = 60;
		else
			g_refRate = r;
	}

	HMENU hMenu = LoadMenu(g_hMod, MAKEINTRESOURCE(IDC_VJR200));
	SetMenu(g_hMainWnd, hMenu);
	SetMenuItemState(hMenu);

	if (g_bFpsCpu) {
		CreateTimerQueueTimer(&hFpsTimer, hTimerQueue,
			(WAITORTIMERCALLBACK)FpsTimerRoutine, NULL, 0, 1000, 0);
	}

	if (!CreateSoundThreads()) return FALSE;

	MSG msg;
	// ���b�Z�[�W��������ѕ`�惋�[�v
	while (TRUE) {
		static int dcount;

		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
			if (msg.message == WM_QUIT) {
				break;
			}
			else {
				if (!TranslateAccelerator(g_hMainWnd, hAccelTable, &msg)) {
					TranslateMessage(&msg);
					DispatchMessage(&msg);
				}
			}
		}
		else {
			if (g_deviceRunning) {
				WINDOWPLACEMENT wndpl;
				GetWindowPlacement(g_hMainWnd, &wndpl);
				if ((wndpl.showCmd != SW_HIDE) &&
					(wndpl.showCmd != SW_MINIMIZE) &&
					(wndpl.showCmd != SW_SHOWMINIMIZED) &&
					(wndpl.showCmd != SW_SHOWMINNOACTIVE)) {

					if (++dcount == 7) { // �f�o�b�O����VSYNC��1/6�񂵂��X�V���Ȃ�
						if (bDebugWindow) InvalidateRect(hWndDebug, NULL, TRUE);
						if (g_bMemWindow) InvalidateRect(g_pMemWindow->GetHWnd(), NULL, FALSE);
						if (g_bDisasmWindow) InvalidateRect(g_pDisasmWindow->GetHWnd(), NULL, FALSE);
						dcount = 0;
					}

					// �T�E���h�Đ��`�F�b�N
					if (g_bSoundOn == false) {
						sys.pMn1271->SoundOn();
					}

					DWORD exitCode = 0;
					GetExitCodeThread(hSoundThread0, &exitCode);
					if (exitCode != STILL_ACTIVE) {
						hSoundThread0 = NULL;
						CreateSoundThreads();
					}
					GetExitCodeThread(hSoundThread1, &exitCode);
					if (exitCode != STILL_ACTIVE) {
						hSoundThread1 = NULL;
						CreateSoundThreads();
					}
					GetExitCodeThread(hSoundThread2, &exitCode);
					if (exitCode != STILL_ACTIVE) {
						hSoundThread2 = NULL;
						CreateSoundThreads();
					}

					sys.pMn1271->CheckStatus();

					g_vcyncCounter = 0;

					// 6800���ߎ��s
					sys.StepRun();

					// �`�揈���̎��s
					++fps;
					if (FAILED(sys.pCrtc->OnRender())) {
						MessageBox(g_hMainWnd, g_stringTable[4], nullptr, 0);
						sys.pCrtc->DiscardDeviceResources();
						sys.Dispose();
						return FALSE;
					}
				}
				else {
					Sleep(20);
				}
			}
			else {
				Sleep(20);
			}
		}
	}

	// �v���O�����I��
	DeleteSoundeThreads();
	if (g_pTapeFormat != nullptr)
		delete g_pTapeFormat;
	timeEndPeriod(1);
	setting.WriteIni();
	DeleteTimerQueueEx(hTimerQueue, NULL);
	CoUninitialize();
	FreeLibrary(g_hMod);
	return (int)msg.wParam;
}



////////////////////////////////////////////////////////////////////////////////////////////////////
//
//  �֐�: MyRegisterClass()
//
//  �ړI: �E�B���h�E �N���X��o�^���܂��B
//
////////////////////////////////////////////////////////////////////////////////////////////////////
ATOM MyRegisterClass(HINSTANCE hInstance)
{
	WNDCLASSEX wcex;

	wcex.cbSize = sizeof(WNDCLASSEX);

	wcex.style = CS_HREDRAW | CS_VREDRAW | CS_DBLCLKS;
	wcex.lpfnWndProc = WndProc;
	wcex.cbClsExtra = 0;
	wcex.cbWndExtra = 0;
	wcex.hInstance = hInstance;
	wcex.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_VJR200));
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
	wcex.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wcex.lpszMenuName = NULL; // MAKEINTRESOURCE(IDC_VJR200);
	wcex.lpszClassName = szWindowClass;
	wcex.hIconSm = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SMALL));

	return RegisterClassEx(&wcex);
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �E�B���h�E�̍쐬�E�\��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
	g_hInst = hInstance; // �O���[�o���ϐ��ɃC���X�^���X�������i�[���܂��B
	DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
	RECT rect;
	if (g_bSquarePixel)
		rect = { 0, 0, BITMAP_W * g_viewScale, BITMAP_H * g_viewScale + GetSystemMetrics(SM_CYMENU) + STATUSBAR_HEIGHT };
	else
		rect = { 0, 0, (int)(BITMAP_W * g_viewScale * REAL_WRATIO), BITMAP_H * g_viewScale + GetSystemMetrics(SM_CYMENU) + STATUSBAR_HEIGHT };

	AdjustWindowRect(&rect, style, FALSE);
	g_windowPos.right = g_windowPos.left + rect.right - rect.left;
	g_windowPos.bottom = g_windowPos.top + rect.bottom - rect.top;
	HWND hWnd = CreateWindow(szWindowClass, szTitle, style,
		g_windowPos.left, g_windowPos.top, g_windowPos.right - g_windowPos.left, g_windowPos.bottom - g_windowPos.top, NULL, NULL, hInstance, nullptr);
	if (!hWnd)
	{
		return FALSE;
	}
	g_hMainWnd = hWnd;

	ShowWindow(hWnd, SW_RESTORE);

	return TRUE;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �E�B���h�E�E�v���V�[�W��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	static DWORD preTime;
	static WPARAM preKey;

	switch (message)
	{
	case WM_COMMAND:
	{
		int wmId = LOWORD(wParam);
		HMENU hMenu = GetMenu(g_hMainWnd);
		// �I�����ꂽ���j���[�̉��:
		switch (wmId)
		{
		case IDM_ABOUT:
			DialogBox(g_hMod, MAKEINTRESOURCE(IDD_ABOUTBOX), hWnd, About);
			break;
		case IDM_EXIT:
			DestroyWindow(hWnd);
			break;
		case IDM_FILE_SETCJR:
		{
			TCHAR fileName[MAX_PATH] = {};
			OpenFileDialog(_T("CJR,JR2 file(*.cjr,*.jr2)\0*.cjr;*.jr2\0"), fileName, g_hMainWnd);
			if (_tcslen(fileName) != 0) {
				int type;
				if ((type = CheckFileFormat(fileName)) != 0) {
					AddRecentFiles(fileName, 0);
					MountTapeFile(fileName, type);
				}
				else {
					MessageBeep(MB_OK);
					MessageBox(NULL, g_stringTable[37], NULL, 0);
				}
			}
		}
		break;
		case IDM_FILE_QLOAD:
		{
			TCHAR fileName[MAX_PATH] = {};
			OpenFileDialog(_T("CJR file(*.cjr)\0*.cjr\0"), fileName, g_hMainWnd);
			if (_tcslen(fileName) != 0) {
				if (CheckFileFormat(fileName) == 1) {
					AddRecentFiles(fileName, 1);
					sys.pAddress->CjrQuickLoad(fileName);
				}
				else {
					MessageBeep(MB_OK);
					MessageBox(NULL, g_stringTable[37], NULL, 0);
				}
			}
			break;
		}
		case IDM_FILE_CJRSAVE:
		{
			DialogBox(g_hMod, MAKEINTRESOURCE(IDD_SAVECJR), hWnd, DlgSaveCjrProc);

			break;
		}
		case  IDM_FILE_JR2EJECT:
		{
			if (g_pTapeFormat == nullptr) break;
			delete g_pTapeFormat;
			g_pTapeFormat = nullptr;
			break;
		}
		case  IDM_FILE_JR2NEW:
		{
			tmpFileName[0] = '\0';
			OPENFILENAME ofn = { 0 };

			ImmAssociateContext(g_hMainWnd, g_hImc);
			ofn.lStructSize = sizeof(OPENFILENAME);
			ofn.hwndOwner = g_hMainWnd;
			ofn.lpstrFilter = _T("JR2 file(*.jr2)");
			ofn.nMaxCustFilter = 256;
			ofn.nFilterIndex = 0;
			ofn.lpstrFile = tmpFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;

			if (GetSaveFileName(&ofn)) {
				TCHAR chkStr[MAX_PATH];
				_tcscpy(chkStr, tmpFileName);
				_tcsupr(chkStr);
				if (_tcsncmp(_tcsrev(chkStr), _T("2RJ."), 3) != 0)
					_tcscat(tmpFileName, _T(".jr2"));

				if (g_pTapeFormat != nullptr) delete g_pTapeFormat;
				g_pTapeFormat = new Jr2Format();
				if (!g_pTapeFormat->Init(tmpFileName))
					MessageBox(g_hMainWnd, g_stringTable[23], NULL, 0);
				else
					 AddRecentFiles(tmpFileName, 0);

			}
			g_hImc = ImmAssociateContext(g_hMainWnd, 0);

			break;
		}
		case IDM_FILE_JR2TOP:
		{
			if (g_pTapeFormat != nullptr)
				g_pTapeFormat->Top();
			break;
		}
		case  IDM_FILE_JR2NEXT:
		{
			if (g_pTapeFormat != nullptr)
				g_pTapeFormat->Next();
			break;
		}
		case  IDM_FILE_JR2PREV:
		{
			if (g_pTapeFormat != nullptr)
				g_pTapeFormat->Prev();
			break;
		}
		case IDM_FILE_QUICKTYPE:
		{
			TCHAR filename[MAX_PATH] = {};
			if (OpenFileDialog(_T("Text file(*.txt)\0*.txt\0All(*.*)\0*.*\0\0"), filename, hWnd)) {
				HANDLE hFile;
				DWORD dwNumberOfReadBytes;
				BOOL ret = true;

				hFile = CreateFile(filename,
					GENERIC_READ,
					0,
					0,
					OPEN_EXISTING,
					0,
					0
				);
				if (hFile == INVALID_HANDLE_VALUE) {
					MessageBeep(MB_OK);
					break;
				}

				quickTYpeDataSize = GetFileSize(hFile, NULL);
				if (quickTYpeDataSize > 65536) {
					CloseHandle(hFile);
					MessageBeep(MB_OK);
					break;
				}

				bQuickTyping = true;
				preCpuScale = g_cpuScale;
				g_cpuScale = CPU_SPEED_MAX;
				if (quickTypeData != nullptr)
					delete[] quickTypeData;
				quickTypeData = new uint8_t[quickTYpeDataSize];

				ret = ReadFile(hFile,
					quickTypeData,
					quickTYpeDataSize / sizeof(quickTypeData[0]),
					&dwNumberOfReadBytes,
					NULL);
				CloseHandle(hFile);

				CreateTimerQueueTimer(&hQuickTypeTimer, hTimerQueue,
					(WAITORTIMERCALLBACK)QuicTypeTimerRoutine, NULL, 0, g_quickTypeS, 0);
			}
			break;
		}
		case IDM_FILE_RESET:
		{
			if (MessageBox(g_hMainWnd, g_stringTable[7], g_stringTable[8], MB_YESNO | MB_ICONWARNING) == IDYES) {
				if (hTimerQueue != NULL)
					DeleteTimerQueueTimer(hTimerQueue, hQuickTypeTimer, NULL);
				sys.pMn1271->SoundOff();
				sys.Dispose();
				sys.Init();
				sys.Start();
				sys.Reset();
				CreateSoundThreads();
			}
			break;
		}
		case IDM_FILE_SAVEMEMIMAGE:
			sys.pAddress->SaveDumpFile();
			break;

		case IDM_FILE_RFILES_SETCJR0:
		case IDM_FILE_RFILES_SETCJR1:
		case IDM_FILE_RFILES_SETCJR2:
		case IDM_FILE_RFILES_SETCJR3:
		case IDM_FILE_RFILES_SETCJR4:
		case IDM_FILE_RFILES_SETCJR5:
		case IDM_FILE_RFILES_SETCJR6:
		case IDM_FILE_RFILES_SETCJR7:
		case IDM_FILE_RFILES_SETCJR8:
		case IDM_FILE_RFILES_SETCJR9:
		{
			int idx = wParam - IDM_FILE_RFILES_SETCJR0;
			if (g_rFilesforCJRSet[idx].size() == 0) break;
			struct _stat buf;
			int st = _tstat(g_rFilesforCJRSet[idx].data(), &buf);
			if (st == 0) {
				int type;
				if ((type = CheckFileFormat(g_rFilesforCJRSet[idx].data())) != 0) {
					MountTapeFile(g_rFilesforCJRSet[idx].data(), type);
					AddRecentFiles(g_rFilesforCJRSet[idx].data(), 0);
				}
				else {
					MessageBeep(MB_OK);
					MessageBox(NULL, g_stringTable[37], NULL, 0);
					break;
				}
			}
			else {
				if (MessageBox(hWnd, g_stringTable[18], NULL, MB_YESNO) == IDYES) {
					g_rFilesforCJRSet.erase(g_rFilesforCJRSet.begin() + idx);
					g_rFilesforCJRSet.push_back(_T(""));
				}
			}
			SetMenuItemForRecentFiles();
			break;
		}
		case IDM_FILE_RFILES_QLOAD0:
		case IDM_FILE_RFILES_QLOAD1:
		case IDM_FILE_RFILES_QLOAD2:
		case IDM_FILE_RFILES_QLOAD3:
		case IDM_FILE_RFILES_QLOAD4:
		case IDM_FILE_RFILES_QLOAD5:
		case IDM_FILE_RFILES_QLOAD6:
		case IDM_FILE_RFILES_QLOAD7:
		case IDM_FILE_RFILES_QLOAD8:
		case IDM_FILE_RFILES_QLOAD9:
		{
			int idx = wParam - IDM_FILE_RFILES_QLOAD0;
			if (g_rFilesforQLoad[idx].size() == 0) break;

			if (!sys.pAddress->CjrQuickLoad(g_rFilesforQLoad[idx].data())) {
				if (MessageBox(hWnd, g_stringTable[18], NULL, MB_YESNO) == IDYES) {
					g_rFilesforQLoad.erase(g_rFilesforQLoad.begin() + idx);
					g_rFilesforQLoad.push_back(_T(""));
				}
			}
			else {
				AddRecentFiles(g_rFilesforQLoad[idx].data(), 1);
			}
			SetMenuItemForRecentFiles();
			break;
		}
		case IDM_VIEW_X1:
		{
			g_viewScale = 1;
			ChangeWindowSize(hMenu);
			sys.pCrtc->Resize(false);
			break;
		}
		case IDM_VIEW_X2:
		{
			g_viewScale = 2;
			ChangeWindowSize(hMenu);
			sys.pCrtc->Resize(false);
			break;
		}
		case IDM_VIEW_X3:
		{
			g_viewScale = 3;
			ChangeWindowSize(hMenu);
			sys.pCrtc->Resize(false);
			break;
		}
		case IDM_VIEW_FULL:
		{
			if (bFullScreen) { // �t���X�N���[������E�B���h�E�ɖ߂�
				SetWindowLong(hWnd, GWL_STYLE, WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX);
				HMENU hMenu = LoadMenu(g_hMod, MAKEINTRESOURCE(IDC_VJR200));
				SetMenu(g_hMainWnd, hMenu);
				SetMenuItemState(hMenu);
				SetWindowPos(hWnd, NULL, g_windowPos.left, g_windowPos.top, g_windowPos.right - g_windowPos.left, g_windowPos.bottom - g_windowPos.top, SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW);
				bFullScreen = false;
				sys.pCrtc->Resize(false);
				while (ShowCursor(TRUE) < 0);
			}
			else { // �E�B���h�E����t���X�N���[����
				GetWindowRect(hWnd, &g_windowPos);
				SetMenu(g_hMainWnd, NULL);
				SetWindowLong(hWnd, GWL_STYLE, WS_VISIBLE | WS_POPUP);//�E�B���h�E�̃X�^�C����ύX
				MoveWindow(hWnd, GetSystemMetrics(SM_XVIRTUALSCREEN),
					GetSystemMetrics(SM_YVIRTUALSCREEN),
					GetSystemMetrics(SM_CXVIRTUALSCREEN),
					GetSystemMetrics(SM_CYVIRTUALSCREEN), TRUE);
				bFullScreen = true;
				sys.pCrtc->Resize(true);
				SetTimer(hWnd, 1, 2000, NULL);
			}
			break;
		}
		case IDM_VIEW_SQUAREPIXEL:
			CheckMenuRadioItem(hMenu, IDM_VIEW_SQUAREPIXEL, IDM_VIEW_REAL, IDM_VIEW_SQUAREPIXEL, MF_BYCOMMAND);
			g_bSquarePixel = true;
			ChangeWindowSize(hMenu);
			sys.pCrtc->Resize(false);
			break;
		case IDM_VIEW_REAL:
			CheckMenuRadioItem(hMenu, IDM_VIEW_SQUAREPIXEL, IDM_VIEW_REAL, IDM_VIEW_REAL, MF_BYCOMMAND);
			g_bSquarePixel = false;
			ChangeWindowSize(hMenu);
			sys.pCrtc->Resize(false);
			break;
		case IDM_VIEW_SMOOTHING:
			if (g_bSmoothing) {
				g_bSmoothing = false;
				CheckMenuItem(hMenu, IDM_VIEW_SMOOTHING, MF_UNCHECKED);
			}
			else {
				g_bSmoothing = true;
				CheckMenuItem(hMenu, IDM_VIEW_SMOOTHING, MF_CHECKED);
			}
			break;
		case IDM_TOOL_VGRAPHKEYBOARD:
		{
			if (bVGraphKeyb) {
				DestroyWindow(hWndVGraphKeyb);
				hWndVGraphKeyb = NULL;
				bVGraphKeyb = false;
				CheckMenuItem(hMenu, IDM_TOOL_VGRAPHKEYBOARD, MF_UNCHECKED);
			}
			else {
				hWndVGraphKeyb = CreateDialog(g_hMod, MAKEINTRESOURCE(IDD_VGRAPHKEYBOARD), g_hMainWnd, DlgVGraphKeybProc);
				ShowWindow(hWndVGraphKeyb, SW_SHOW);
				bVGraphKeyb = true;
				CheckMenuItem(hMenu, IDM_TOOL_VGRAPHKEYBOARD, MF_CHECKED);
				RECT rect;
				GetWindowRect(hWndVGraphKeyb, &rect);
				MoveWindow(hWndVGraphKeyb, 0, 0, rect.right - rect.left, rect.bottom - rect.top, FALSE);
			}
			break;
		}
		case IDM_TOOL_FORCEDJOYSTICK:
		{
			if (g_bForcedJoystick) {
				g_bForcedJoystick = false;
				CheckMenuItem(hMenu, IDM_TOOL_FORCEDJOYSTICK, MF_UNCHECKED);
			}
			else {
				g_bForcedJoystick = true;
				CheckMenuItem(hMenu, IDM_TOOL_FORCEDJOYSTICK, MF_CHECKED);
			}
			break;
		}
		case IDM_TOOL_DEBUGWINDOW:
		{
			if (bDebugWindow) {
				DestroyWindow(hWndDebug);
				hWndDebug = NULL;
				bDebugWindow = false;
				CheckMenuItem(hMenu, IDM_TOOL_DEBUGWINDOW, MF_UNCHECKED);
			}
			else {
				hWndDebug = CreateDialog(g_hMod, MAKEINTRESOURCE(IDD_DEBUGWINDOW), g_hMainWnd, DlgDebugProc);
				ShowWindow(hWndDebug, SW_SHOW);
				bDebugWindow = true;
				CheckMenuItem(hMenu, IDM_TOOL_DEBUGWINDOW, MF_CHECKED);
				RECT rect;
				GetWindowRect(hWndDebug, &rect);
				MoveWindow(hWndDebug, 0, 0, rect.right - rect.left, rect.bottom - rect.top, FALSE);
			}
			break;
		}
		case IDM_TOOL_MEMORYWINDOW:
		{
			if (g_bMemWindow) {
				g_pMemWindow->Close();
				g_bMemWindow = false;
				CheckMenuItem(hMenu, IDM_TOOL_MEMORYWINDOW, MF_UNCHECKED);
			}
			else {
				g_pMemWindow = new MemWindow();
				g_pMemWindow->Init();
				g_bMemWindow = true;
				CheckMenuItem(hMenu, IDM_TOOL_MEMORYWINDOW, MF_CHECKED);
			}

			break;
		}
		case IDM_TOOL_DISASSEMBLEWINDOW:
		{
			if (g_bDisasmWindow) {
				g_pDisasmWindow->Close();
				g_bDisasmWindow = false;
				CheckMenuItem(hMenu, IDM_TOOL_DISASSEMBLEWINDOW, MF_UNCHECKED);
			}
			else {
				g_pDisasmWindow = new DisasmWindow();
				g_pDisasmWindow->Init();
				g_bDisasmWindow = true;
				CheckMenuItem(hMenu, IDM_TOOL_DISASSEMBLEWINDOW, MF_CHECKED);
			}

			break;
		}
		case IDM_TOOL_ROMFONT:
			DialogBox(g_hMod, MAKEINTRESOURCE(IDD_ROMFONTSETTING), hWnd, DlgRomFontProc);
			break;
		case IDM_TOOL_FPSCPU:
		{
			if (g_bFpsCpu)
			{
				DeleteTimerQueueTimer(hTimerQueue, hFpsTimer, NULL);
				SetWindowText(hWnd, _T("VJR-200"));
				CheckMenuItem(hMenu, IDM_TOOL_FPSCPU, MF_UNCHECKED);
				g_bFpsCpu = false;
			}
			else {
				CreateTimerQueueTimer(&hFpsTimer, hTimerQueue,
					(WAITORTIMERCALLBACK)FpsTimerRoutine, NULL, 0, 1000, 0);
				CheckMenuItem(hMenu, IDM_TOOL_FPSCPU, MF_CHECKED);
				g_bFpsCpu = true;
			}

		}
			break;
		case IDM_TOOL_OPTION:
		{
			DialogBox(g_hMod, MAKEINTRESOURCE(IDD_OPTIONDIALOG), hWnd, DlgOptionProc);
			break;
		}
		default:
			return DefWindowProc(hWnd, message, wParam, lParam);
		}
		break;
	}
	case WM_TIMER:
		switch (wParam)
		{
		case 1:
			// �t���X�N���[�����̃J�[�\��
			KillTimer(hWnd, 1);
			if (bFullScreen)
				while (ShowCursor(FALSE) >= 0);
			break;
		}
		break;
	case WM_MOUSEMOVE:
		if (bFullScreen) {
			while (ShowCursor(TRUE) < 0);
			SetTimer(hWnd, 1, 2000, NULL);
		}
		break;
	case WM_KEYDOWN:
	{
		// �N�C�b�N�^�C�v�𒆎~����ۂ�esc�L�[������ʏ���
		//
		if (bQuickTyping && wParam == VK_ESCAPE) {
			DeleteTimerQueueTimer(hTimerQueue, hQuickTypeTimer, NULL);
			hTimerQueue = NULL;
			bQuickTyping = false;
			delete[] quickTypeData;
			quickTypeData = nullptr;
			quickTypeCount = 0;
			g_cpuScale = preCpuScale;
		}

		// �L�[���s�[�g��}�����邽�߁A50ms�ȏソ���Ȃ��Ǝ��̃��s�[�g���������Ȃ�
		DWORD currentTime = timeGetTime();
		if (currentTime - preTime < 50 && preKey == wParam) break;
		preTime = currentTime;
		preKey = wParam;
		sys.pMn1544->KeyIn((int)wParam);
	}
	break;
	case WM_LBUTTONDBLCLK:
	{
		SendMessage(hWnd, WM_COMMAND, IDM_VIEW_FULL, 0);
		break;
	}
	case WM_PAINT:
	{
		// ROM,FONT�t�@�C�����Ȃ��ꍇ�̃G���[���b�Z�[�W�݂̂����ŕ\��
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hWnd, &ps);
		if (_tcslen(g_pRomFile) == 0) {
			RECT rect = { 5, 5, 600, 50 };
			DrawText(hdc, g_stringTable[9], -1, &rect, 0);
		}
		if (_tcslen(g_pFontFile) == 0) {
			RECT rect = { 5, 50, 600, 100 };
			DrawText(hdc, g_stringTable[10], -1, &rect, 0);
		}
		EndPaint(hWnd, &ps);
	}
	break;
	case WM_DESTROY:
		sys.pMn1271->SoundOff();
		GetWindowRect(hWnd, &g_windowPos);
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hWnd, message, wParam, lParam);
	}
	return 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �o�[�W�������{�b�N�X�̃��b�Z�[�W �n���h���[�ł��B
//
////////////////////////////////////////////////////////////////////////////////////////////////////
INT_PTR CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		return (INT_PTR)TRUE;

	case WM_COMMAND:
		if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL)
		{
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
		}
		break;
	}
	return (INT_PTR)FALSE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ���z�L�[�{�[�h�̃E�B���h�E�E�v���V�[�W��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DlgVGraphKeybProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	static HBITMAP hBitmap1, hBitmap2;

	switch (msg) {
	case WM_INITDIALOG:
	{
		hBitmap1 = CreateBitmap(112, 32, 1, 1, g_bits1);
		hBitmap2 = CreateBitmap(112, 24, 1, 1, g_bits2);
		return (INT_PTR)TRUE;
		break;
	}
	case WM_CLOSE:
		DeleteObject(hBitmap1);
		DeleteObject(hBitmap2);
		DestroyWindow(hWndVGraphKeyb);
		hWndVGraphKeyb = NULL;
		bVGraphKeyb = false;
		CheckMenuItem(GetMenu(g_hMainWnd), IDM_TOOL_VGRAPHKEYBOARD, MF_UNCHECKED);
		return (INT_PTR)TRUE;
		break;
	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
	{
		int x = GET_X_LPARAM(lp) - 10;
		int y = GET_Y_LPARAM(lp);
		if (x < 0)
			return (INT_PTR)TRUE;
		if (y < 120) {
			y -= 10;
			if (y < 0)
				return (INT_PTR)TRUE;
			x /= 24;
			y /= 24;
			if (x >= 13 || y >= 4)
				return (INT_PTR)TRUE;
			uint8_t c = g_gcharCode1[y][x];
			if (c == 0)
				return (INT_PTR)TRUE;
			sys.pAddress->WriteByte(0xc801, c);
			sys.pMn1271->AssertIrq((int)(IrqType::KON));
		}
		else {
			y -= 120;
			if (y < 0)
				return (INT_PTR)TRUE;
			x /= 24;
			y /= 24;
			if (x >= 13 || y >= 3)
				return (INT_PTR)TRUE;
			uint8_t c = g_gcharCode2[y][x];
			if (c == 0)
				return (INT_PTR)TRUE;
			sys.pAddress->WriteByte(0xc801, c);
			sys.pMn1271->AssertIrq((int)(IrqType::KON));
		}
		return (INT_PTR)TRUE;
		break;
	}
	case WM_PAINT:
	{
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		HDC hdcMem1 = CreateCompatibleDC(hdc);
		HDC hdcMem2 = CreateCompatibleDC(hdc);
		SelectObject(hdcMem1, hBitmap1);
		SelectObject(hdcMem2, hBitmap2);
		HPEN hOldPen, hPen = (HPEN)GetStockObject(BLACK_PEN);

		StretchBlt(hdc, 0 + 10 , 0 + 10, 312, 96, hdcMem1, 0, 0, 104, 32, SRCCOPY);
		StretchBlt(hdc, 0 + 10, 0 + 120, 312, 72, hdcMem2, 0, 0, 104, 24, SRCCOPY);
		hOldPen = (HPEN)SelectObject(hdc, hPen);
		for (int i = 0; i <= 13; ++i) {
			MoveToEx(hdc, i * 24 + 10, 0 + 10, NULL);
			LineTo(hdc, i * 24 + 10, 96 + 10);
		}
		for (int i = 0; i <= 4; ++i) {
			MoveToEx(hdc, 0 + 10, i * 24 + 10, NULL);
			LineTo(hdc, 312 + 10, i * 24 + 10);
		}

		for (int i = 0; i <= 13; ++i) {
			MoveToEx(hdc, i * 24 + 10, 0 + 120, NULL);
			LineTo(hdc, i * 24 + 10, 72 + 120);
		}
		for (int i = 0; i <= 3; ++i) {
			MoveToEx(hdc, 0 + 10, i * 24 + 120, NULL);
			LineTo(hdc, 312 + 10, i * 24 + 120);
		}
		SelectObject(hdc, hOldPen);
		DeleteObject(hPen);
		DeleteDC(hdcMem1);
		DeleteDC(hdcMem2);
		EndPaint(hwnd, &ps);
		return (INT_PTR)TRUE;
		break;
	}
	}
	return (INT_PTR)FALSE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �f�o�b�O�E�E�B���h�E�̃E�B���h�E�E�v���V�[�W��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DlgDebugProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp)
{
	switch (msg) {
	case WM_INITDIALOG:
		if (sys.pMn1271->debugTcaEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCA, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCA, BST_UNCHECKED);
		if (sys.pMn1271->debugTcbEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCB, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCB, BST_UNCHECKED);
		if (sys.pMn1271->debugTccEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCC, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCC, BST_UNCHECKED);
		if (sys.pMn1271->debugTcdEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCD, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCD, BST_UNCHECKED);
		if (sys.pMn1271->debugTceEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCE, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCE, BST_UNCHECKED);
		if (sys.pMn1271->debugTcfEnable)
			CheckDlgButton(hwnd, IDC_DEBUG_TCF, BST_CHECKED);
		else
			CheckDlgButton(hwnd, IDC_DEBUG_TCF, BST_UNCHECKED);
		break;
	case WM_COMMAND:
		switch (wp)
		{
		case IDC_DEBUG_PAUSE:
			g_debug = 0;
			break;
		case IDC_DEBUG_STEP:
			if (g_bMemWindow) InvalidateRect(g_hMemWnd, NULL, TRUE);
			g_debug = 1;
			break;
		case IDC_DEBUG_PLAY:
			g_debug = -1;
			break;
		case IDC_DEBUG_SET:
		{
			TCHAR buff[6];
			GetDlgItemText(hwnd, IDC_DEBUG_BREAKPOINT, buff, 6);
			TCHAR* e;
			unsigned int address = _tcstol(buff, &e, 16);
			if (*e == '\0' && address > 0 && address < 66656) {
				g_breakPoint = address;
			}
			else {
				g_breakPoint = -1;
				MessageBeep(MB_OK);
				SetDlgItemText(hwnd, IDC_DEBUG_BREAKPOINT, _T(""));
			}

			break;
		}
		case IDC_DEBUG_TCA:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCA))
				sys.pMn1271->debugTcaEnable = true;
			else
				sys.pMn1271->debugTcaEnable = false;
			break;
		case IDC_DEBUG_TCB:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCB))
				sys.pMn1271->debugTcbEnable = true;
			else
				sys.pMn1271->debugTcbEnable = false;
			break;
		case IDC_DEBUG_TCC:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCC))
				sys.pMn1271->debugTccEnable = true;
			else
				sys.pMn1271->debugTccEnable = false;
			break;
		case IDC_DEBUG_TCD:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCD))
				sys.pMn1271->debugTcdEnable = true;
			else
				sys.pMn1271->debugTcdEnable = false;
			break;
		case IDC_DEBUG_TCE:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCE))
				sys.pMn1271->debugTceEnable = true;
			else
				sys.pMn1271->debugTceEnable = false;
			break;
		case IDC_DEBUG_TCF:
			if (IsDlgButtonChecked(hwnd, IDC_DEBUG_TCF))
				sys.pMn1271->debugTcfEnable = true;
			else
				sys.pMn1271->debugTcfEnable = false;
			break;
		}
		return TRUE;
		break;
	case WM_CLOSE:
		g_debug = -1;
		DestroyWindow(hWndDebug);
		hWndDebug = NULL;
		bDebugWindow = false;
		CheckMenuItem(GetMenu(g_hMainWnd), IDM_TOOL_DEBUGWINDOW, MF_UNCHECKED);
		return TRUE;
	case WM_PAINT:
	{
		TCHAR c[40] = {};
		uint16_t pc, sp, x;
		uint8_t a, b, cc;
		sys.pCpu->GetRegister(pc, sp, x, a, b, cc);
		PAINTSTRUCT ps;
		HDC hdc = BeginPaint(hwnd, &ps);
		HFONT hFont, hFontOld;
		hFont = CreateFont(16,
			0,
			0,
			0,
			FW_NORMAL,
			FALSE,
			FALSE,
			FALSE,
			ANSI_CHARSET,
			OUT_DEFAULT_PRECIS,
			CLIP_DEFAULT_PRECIS,
			PROOF_QUALITY,
			FIXED_PITCH | FF_MODERN,
			_T("Courier New"));

		hFontOld = (HFONT)SelectObject(hdc, hFont);


		wsprintf(c, _T("PC=%04X   SP=%04X"), pc, sp);
		TextOut(hdc, 10, 10, c, _tcslen(c));
		ZeroMemory(c, 40);
		wsprintf(c, _T("A=%02X   B=%02X   X=%04X"), a, b, x);
		TextOut(hdc, 10, 25, c, _tcslen(c));
		ZeroMemory(c, 40);
		wsprintf(c, _T("CC - - H I N Z V C"));
		TextOut(hdc, 10, 40, c, _tcslen(c));
		ZeroMemory(c, 40);
		wsprintf(c, _T("%02X 1 1 %d %d %d %d %d %d"), cc, (cc & 0x20) ? 1 : 0, (cc & 0x10) ? 1 : 0, (cc & 0x08) ? 1 : 0,
			(cc & 0x04) ? 1 : 0, (cc & 0x02) ? 1 : 0, (cc & 0x01) ? 1 : 0);
		TextOut(hdc, 10, 55, c, _tcslen(c));

		for (int i = 0; i < 32; ++i) {
			ioReg[i] = sys.pAddress->ReadByteForDebug(0xc800 + i);
		}
		wsprintf(c, _T("MN1271"));
		TextOut(hdc, 10, 70, c, _tcslen(c));

		wsprintf(c, _T("00 01 02 03 04 05 06 07"));
		TextOut(hdc, 10, 85, c, _tcslen(c));
		wsprintf(c, _T("%02X %02X %02X %02X %02X %02X %02X %02X"), ioReg[0], ioReg[1], ioReg[2], ioReg[3], ioReg[4], ioReg[5], ioReg[6], ioReg[7]);
		TextOut(hdc, 10, 100, c, _tcslen(c));

		wsprintf(c, _T("08 09 0A 0B 0C 0D 0E 0F"));
		TextOut(hdc, 10, 120, c, _tcslen(c));
		wsprintf(c, _T("%02X %02X %02X %02X %02X %02X %02X %02X"), ioReg[8], ioReg[9], ioReg[10], ioReg[11], ioReg[12], ioReg[13], ioReg[14], ioReg[15]);
		TextOut(hdc, 10, 135, c, _tcslen(c));

		wsprintf(c, _T("10 11 12 13 14 15 16 17"));
		TextOut(hdc, 10, 155, c, _tcslen(c));
		wsprintf(c, _T("%02X %02X %02X %02X %02X %02X %02X %02X"), ioReg[16], ioReg[17], ioReg[18], ioReg[19], ioReg[20], ioReg[21], ioReg[22], ioReg[23]);
		TextOut(hdc, 10, 170, c, _tcslen(c));

		wsprintf(c, _T("18 19 1A 1B 1C 1D 1E 1F"));
		TextOut(hdc, 10, 190, c, _tcslen(c));
		wsprintf(c, _T("%02X %02X %02X %02X %02X %02X %02X %02X"), ioReg[24], ioReg[25], ioReg[26], ioReg[27], ioReg[28], ioReg[29], ioReg[30], ioReg[31]);
		TextOut(hdc, 10, 205, c, _tcslen(c));

		SelectObject(hdc, hFontOld);
		DeleteObject(hFont);
		EndPaint(hwnd, &ps);
		return TRUE;
		break;
	}
	}
	return FALSE;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ROM,FONT�t�@�C���ݒ�_�C�A���O�̃E�B���h�E�E�v���V�[�W��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DlgRomFontProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SetDlgItemText(hDlg, IDC_ROMFILE, g_pRomFile);
		SetDlgItemText(hDlg, IDC_FONTFILE, g_pFontFile);
		return (INT_PTR)TRUE;
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDOK:
		{
			TCHAR buff[MAX_PATH];
			int len;

			GetDlgItemText(hDlg, IDC_ROMFILE, buff, MAX_PATH);
			len = _tcslen(buff);

			if (len == 0) {
				MessageBox(hDlg, g_stringTable[12], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}

			HANDLE hFile;
			hFile = CreateFile(buff,
				GENERIC_READ,
				0,
				0,
				OPEN_EXISTING,
				0,
				0
			);
			if (hFile == INVALID_HANDLE_VALUE) {
				CloseHandle(hFile);
				MessageBox(hDlg, g_stringTable[14], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}

			if (GetFileSize(hFile, NULL) != 16384) {
				CloseHandle(hFile);
				MessageBox(hDlg, g_stringTable[15], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}
			CloseHandle(hFile);
			_tcscpy(g_pRomFile, buff);

			// FONT�t�@�C��
			GetDlgItemText(hDlg, IDC_FONTFILE, buff, MAX_PATH);
			len = _tcslen(buff);

			if (len == 0) {
				MessageBox(hDlg, g_stringTable[12], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}

			hFile = CreateFile(buff,
				GENERIC_READ,
				0,
				0,
				OPEN_EXISTING,
				0,
				0
			);
			if (hFile == INVALID_HANDLE_VALUE) {
				CloseHandle(hFile);
				MessageBox(hDlg, g_stringTable[16], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}

			if (GetFileSize(hFile, NULL) != 2048) {
				CloseHandle(hFile);
				MessageBox(hDlg, g_stringTable[16], g_stringTable[13], 0);
				return (INT_PTR)TRUE;
			}
			CloseHandle(hFile);
			_tcscpy(g_pFontFile, buff);

			setting.WriteIni();
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
			break;
		}
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
			break;
		case IDC_ROMFONT_ROMFILEOPEN:
		{
			TCHAR filename[MAX_PATH] = {};
			if (OpenFileDialog(_T("ROM file(*.*)\0*.*\0"), filename, hDlg))
				SetDlgItemText(hDlg, IDC_ROMFILE, filename);
			return (INT_PTR)TRUE;
			break;
		}
		case IDC_ROMFONT_FONTFILEOPEN:
		{
			TCHAR filename[MAX_PATH] = {};
			if (OpenFileDialog(_T("Font flie(*.*)\0*.*\0"), filename, hDlg))
				SetDlgItemText(hDlg, IDC_FONTFILE, filename);
			return (INT_PTR)TRUE;
			break;
		}
		}
		break;
	}
	return (INT_PTR)FALSE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���E�I�[�v���E�_�C�A���O�̋��ʃ��[�`��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL OpenFileDialog(TCHAR* filter, TCHAR* fileName, HWND hwnd)
{
	OPENFILENAME ofn = { };

	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = hwnd;
	ofn.lpstrFilter = filter;
	ofn.nMaxCustFilter = 256;
	ofn.nFilterIndex = 0;
	ofn.lpstrFile = fileName;
	ofn.nMaxFile = MAX_PATH;
	ofn.Flags = OFN_FILEMUSTEXIST;

	return GetOpenFileName(&ofn);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�ۑ��E�_�C�A���O�̃E�B���h�E�E�v���V�[�W��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
BOOL CALLBACK DlgSaveCjrProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	UNREFERENCED_PARAMETER(lParam);
	switch (message)
	{
	case WM_INITDIALOG:
		SetFocus(GetDlgItem(hDlg, IDC_SAVECJR_JRNAME));
		return (INT_PTR)TRUE;
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_SAVECJR_SAVEBASIC:
		{
			char jrName[20];
			GetDlgItemTextA(hDlg, IDC_SAVECJR_JRNAME, jrName, 20);
			if (strlen(jrName) == 0) {
				MessageBox(hDlg, g_stringTable[20], g_stringTable[13], 0);
				break;
			}
			if (strlen(jrName) > 16) {
				MessageBox(hDlg, g_stringTable[21], g_stringTable[13], 0);
				break;
			}
			CjrFormat cjr;
			uint8_t* saveData = cjr.MemToCjrBasic(jrName);
			if (sys.pAddress->ReadByte(0x801) == 0) {
				MessageBox(hDlg, g_stringTable[22], g_stringTable[13], 0);
				break;
			}
			int size = cjr.GetCjrSize();

			ImmAssociateContext(g_hMainWnd, g_hImc);

			OPENFILENAME ofn = {0};
			ofn.lStructSize = sizeof(OPENFILENAME);
			ofn.hwndOwner = hDlg;
			ofn.lpstrFilter = g_stringTable[5];
			ofn.nMaxCustFilter = 256;
			ofn.nFilterIndex = 0;
			ofn.lpstrFile = tmpFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;

			if (GetSaveFileName(&ofn)) {
				TCHAR chkStr[MAX_PATH];
				_tcscpy(chkStr, tmpFileName);
				_tcsupr(chkStr);
				if (_tcsncmp(_tcsrev(chkStr), _T("RJC."), 4) != 0)
					_tcscat(tmpFileName, _T(".cjr"));

				HANDLE hFile;
				DWORD dwNumberOfBytesWritten;
				hFile = CreateFile(tmpFileName,
					GENERIC_WRITE,
					0,
					0,
					CREATE_ALWAYS,
					0,
					0
				);
				if (hFile == INVALID_HANDLE_VALUE) {
					MessageBox(hDlg, g_stringTable[23], NULL, 0);
					CloseHandle(hFile);
					break;
				}

				WriteFile(hFile,
					saveData,
					size,
					&dwNumberOfBytesWritten,
					NULL);

				CloseHandle(hFile);
			}
			g_hImc = ImmAssociateContext(g_hMainWnd, 0);
			break;
		}
		case IDC_SAVECJR_SAVEBINARY:
		{
			char jrName[20];
			GetDlgItemTextA(hDlg, IDC_SAVECJR_JRNAME, jrName, 20);
			if (strlen(jrName) == 0) {
				MessageBox(hDlg, g_stringTable[20], g_stringTable[13], 0);
				break;
			}
			if (strlen(jrName) > 16) {
				MessageBox(hDlg, g_stringTable[21], g_stringTable[13], 0);
				break;
			}

			char buff[20];
			char* e;
			unsigned int start, end;
			GetDlgItemTextA(hDlg, IDC_SAVECJR_SADDRESS, buff, 20);
			start = strtol(buff, &e, 16);
			if (start == 0 && *e != '\0') {
				MessageBox(hDlg, g_stringTable[24], NULL, 0);
				break;
			}
			if (start > 65535) {
				MessageBox(hDlg, g_stringTable[25], NULL, 0);
				break;
			}

			GetDlgItemTextA(hDlg, IDC_SAVECJR_EADDRESS, buff, 20);
			end = strtol(buff, &e, 16);
			if (end == 0 && *e != '\0') {
				MessageBox(hDlg, g_stringTable[26], NULL, 0);
				break;
			}
			if (end > 65535) {
				MessageBox(hDlg, g_stringTable[25], NULL, 0);
				break;
			}

			if (start >= end) {
				MessageBox(hDlg, g_stringTable[27], NULL, 0);
				break;
			}

			ImmAssociateContext(g_hMainWnd, g_hImc);

			OPENFILENAME ofn = {0};
			ofn.lStructSize = sizeof(OPENFILENAME);
			ofn.hwndOwner = hDlg;
			ofn.lpstrFilter = g_stringTable[5];
			ofn.nMaxCustFilter = 256;
			ofn.nFilterIndex = 0;
			ofn.lpstrFile = tmpFileName;
			ofn.nMaxFile = MAX_PATH;
			ofn.Flags = OFN_FILEMUSTEXIST | OFN_OVERWRITEPROMPT;

			if (GetSaveFileName(&ofn)) {
				TCHAR chkStr[MAX_PATH];
				_tcscpy(chkStr, tmpFileName);
				_tcsupr(chkStr);
				if (_tcsncmp(_tcsrev(chkStr), _T("RJC."), 4) != 0)
					_tcscat(tmpFileName, _T(".cjr"));

				CjrFormat cjr;
				uint8_t* saveData = cjr.MemToCjrBin(jrName, start, end);

				int size = cjr.GetCjrSize();

				HANDLE hFile;
				DWORD dwNumberOfBytesWritten;
				hFile = CreateFile(tmpFileName,
					GENERIC_WRITE,
					0,
					0,
					CREATE_ALWAYS,
					0,
					0
				);
				if (hFile == INVALID_HANDLE_VALUE) {
					MessageBox(hDlg, g_stringTable[23], NULL, 0);
					CloseHandle(hFile);
					break;
				}

				WriteFile(hFile,
					saveData,
					size,
					&dwNumberOfBytesWritten,
					NULL);

				CloseHandle(hFile);
			}

			g_hImc = ImmAssociateContext(g_hMainWnd, 0);
			break;
		}
		case IDCANCEL:
			EndDialog(hDlg, LOWORD(wParam));
			return (INT_PTR)TRUE;
			break;
		}
		break;
	}
	return (INT_PTR)FALSE;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// FPS�\���^�C�}�̃R�[���o�b�N�E���[�`��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
VOID CALLBACK FpsTimerRoutine(PVOID lpParam, BOOLEAN TimerOrWaitFired)
{
	TCHAR c[40];
	wsprintf(c, _T("VJR-200        %dFPS   CLOCK %d %%"), fps, g_cpuScale);
	SetWindowText(g_hMainWnd, c);
	fps = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �N�C�b�N�^�C�v���̓^�C�}�̃R�[���o�b�N�E���[�`��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
VOID CALLBACK QuicTypeTimerRoutine(PVOID lpParam, BOOLEAN TimerOrWaitFired)
{
	uint8_t keyin = quickTypeData[quickTypeCount++];
	if (keyin == 0x0a)
		keyin = quickTypeData[quickTypeCount++];
	sys.pAddress->WriteByte(0xc801, keyin);
	sys.pMn1271->AssertIrq((int)(IrqType::KON));
	if (quickTypeCount >= quickTYpeDataSize - 1) {
		DeleteTimerQueueTimer(hTimerQueue, hQuickTypeTimer, NULL);
		hTimerQueue = NULL;
		bQuickTyping = false;
		delete[] quickTypeData;
		quickTypeData = nullptr;
		quickTypeCount = 0;
		g_cpuScale = preCpuScale;
	}
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �E�B���h�E�E�T�C�Y���ύX���ꂽ���̏���
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void ChangeWindowSize(HMENU hMenu)
{
	int mes;
	switch (g_viewScale)
	{
	case 1:
		mes = IDM_VIEW_X1;
		break;
	case 2:
		mes = IDM_VIEW_X2;
		break;
	case 3:
		mes = IDM_VIEW_X3;
		break;
	}
	int client_h = BITMAP_H * g_viewScale;
	int client_w = BITMAP_W * g_viewScale;
	CheckMenuRadioItem(hMenu, IDM_VIEW_X1, IDM_VIEW_X3, mes, MF_BYCOMMAND);
	DWORD style = WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX;
	RECT rect;
	if (g_bSquarePixel)
		rect = { 0, 0, client_w, client_h + GetSystemMetrics(SM_CYMENU) + STATUSBAR_HEIGHT };
	else
		rect = { 0, 0, (int)(client_w * REAL_WRATIO), client_h + GetSystemMetrics(SM_CYMENU) + STATUSBAR_HEIGHT };
	AdjustWindowRect(&rect, style, FALSE);
	SetWindowPos(g_hMainWnd, HWND_TOP, 10, 10, rect.right - rect.left, rect.bottom - rect.top, SWP_NOMOVE);

}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ���j���[���e���ύX���ꂽ���̏���
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void SetMenuItemState(HMENU hMenu)
{
	switch (g_viewScale)
	{
	case 1:
		CheckMenuRadioItem(hMenu, IDM_VIEW_X1, IDM_VIEW_X3, IDM_VIEW_X1, MF_BYCOMMAND);
		break;
	case 2:
		CheckMenuRadioItem(hMenu, IDM_VIEW_X1, IDM_VIEW_X3, IDM_VIEW_X2, MF_BYCOMMAND);
		break;
	case 3:
		CheckMenuRadioItem(hMenu, IDM_VIEW_X1, IDM_VIEW_X3, IDM_VIEW_X3, MF_BYCOMMAND);
		break;
	}

	if (g_bSquarePixel) {
		CheckMenuRadioItem(hMenu, IDM_VIEW_SQUAREPIXEL, IDM_VIEW_REAL, IDM_VIEW_SQUAREPIXEL, MF_BYCOMMAND);
	}
	else {
		CheckMenuRadioItem(hMenu, IDM_VIEW_SQUAREPIXEL, IDM_VIEW_REAL, IDM_VIEW_REAL, MF_BYCOMMAND);
	}


	if (g_bSmoothing) {
		CheckMenuItem(hMenu, IDM_VIEW_SMOOTHING, MF_CHECKED);
	}
	else {
		CheckMenuItem(hMenu, IDM_VIEW_SMOOTHING, MF_UNCHECKED);
	}

	if (g_bFpsCpu) {
		CheckMenuItem(hMenu, IDM_TOOL_FPSCPU, MF_CHECKED);
	}
	else {
		CheckMenuItem(hMenu, IDM_TOOL_FPSCPU, MF_UNCHECKED);
	}

	SetMenuItemForRecentFiles();
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ���t���b�V�����[�g�̎擾�i����Ɏ擾�ł��Ȃ����60Hz�ɐݒ�j
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int GetRefreshRate()
{
	int ret;

	HDC hdc = GetDC(g_hMainWnd);
	ret = GetDeviceCaps(hdc, VREFRESH);
	ReleaseDC(g_hMainWnd, hdc);
	if (ret == 0 || ret == 1)
		ret = 60;

	return ret;
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �T�E���h�Đ��p�̃X���b�h�쐬
//
////////////////////////////////////////////////////////////////////////////////////////////////////
bool CreateSoundThreads()
{
	bool val = true;

	unsigned int dwThreadId;
	if (hSoundThread0 == NULL)
		hSoundThread0 = (HANDLE)_beginthreadex(NULL, 0, &SoundSetThread0, NULL, 0, &dwThreadId);
	if (hSoundThread0 == NULL) val = false;

	if (hSoundThread1 == NULL)
		hSoundThread1 = (HANDLE)_beginthreadex(NULL, 0, &SoundSetThread1, NULL, 0, &dwThreadId);
	if (hSoundThread1 == NULL) val = false;

	if (hSoundThread2 == NULL)
		hSoundThread2 = (HANDLE)_beginthreadex(NULL, 0, &SoundSetThread2, NULL, 0, &dwThreadId);
	if (hSoundThread2 == NULL) val = false;

	return val;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �T�E���h�Đ��p�̃X���b�h�폜
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void DeleteSoundeThreads()
{
	if (hSoundThread0 != NULL)
		CloseHandle(hSoundThread0);
	if (hSoundThread1 != NULL)
		CloseHandle(hSoundThread1);
	if (hSoundThread2 != NULL)
		CloseHandle(hSoundThread2);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �T�E���h�Đ��p�̃X���b�h���s���[�`��(0)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned __stdcall SoundSetThread0(void *p)
{
	sys.pMn1271->SoundDataCopy(0, 0);
	sys.pMn1271->SoundDataCopy(0, 1);
	sys.pMn1271->SoundDataCopy(0, 2);
	sys.pMn1271->SoundDataCopy(0, 3);

	while (true) {
		DWORD i = WaitForMultipleObjects(6, g_hEvent[0], FALSE, INFINITE);
		switch (i) {
		case WAIT_OBJECT_0:
			sys.pMn1271->SoundDataCopy(0, 4);
			break;
		case WAIT_OBJECT_0 + 1:
			sys.pMn1271->SoundDataCopy(0, 0);
			break;
		case WAIT_OBJECT_0 + 2:
			sys.pMn1271->SoundDataCopy(0, 1);
			break;
		case WAIT_OBJECT_0 + 3:
			sys.pMn1271->SoundDataCopy(0, 2);
			break;
		case WAIT_OBJECT_0 + 4:
			sys.pMn1271->SoundDataCopy(0, 3);
			break;
		case WAIT_OBJECT_0 + 5:
		default:
			g_bSoundOn = false;
			_endthreadex(0);
			break;
		}
	}
	return 0L;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �T�E���h�Đ��p�̃X���b�h���s���[�`��(1)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned __stdcall SoundSetThread1(void *p)
{
	sys.pMn1271->SoundDataCopy(1, 0);
	sys.pMn1271->SoundDataCopy(1, 1);
	sys.pMn1271->SoundDataCopy(1, 2);
	sys.pMn1271->SoundDataCopy(1, 3);

	while (true) {
		DWORD i = WaitForMultipleObjects(6, g_hEvent[1], FALSE, INFINITE);
		switch (i) {
		case WAIT_OBJECT_0:
			sys.pMn1271->SoundDataCopy(1, 4);
			break;
		case WAIT_OBJECT_0 + 1:
			sys.pMn1271->SoundDataCopy(1, 0);
			break;
		case WAIT_OBJECT_0 + 2:
			sys.pMn1271->SoundDataCopy(1, 1);
			break;
		case WAIT_OBJECT_0 + 3:
			sys.pMn1271->SoundDataCopy(1, 2);
			break;
		case WAIT_OBJECT_0 + 4:
			sys.pMn1271->SoundDataCopy(1, 3);
			break;
		case WAIT_OBJECT_0 + 5:
		default:
			g_bSoundOn = false;
			_endthreadex(0);
			break;
		}
	}
	return 0L;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �T�E���h�Đ��p�̃X���b�h���s���[�`��(2)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
unsigned __stdcall SoundSetThread2(void *p)
{
	sys.pMn1271->SoundDataCopy(2, 0);
	sys.pMn1271->SoundDataCopy(2, 1);
	sys.pMn1271->SoundDataCopy(2, 2);
	sys.pMn1271->SoundDataCopy(2, 3);

	while (true) {
		DWORD i = WaitForMultipleObjects(6, g_hEvent[2], FALSE, INFINITE);
		switch (i) {
		case WAIT_OBJECT_0:
			sys.pMn1271->SoundDataCopy(2, 4);
			break;
		case WAIT_OBJECT_0 + 1:
			sys.pMn1271->SoundDataCopy(2, 0);
			break;
		case WAIT_OBJECT_0 + 2:
			sys.pMn1271->SoundDataCopy(2, 1);
			break;
		case WAIT_OBJECT_0 + 3:
			sys.pMn1271->SoundDataCopy(2, 2);
			break;
		case WAIT_OBJECT_0 + 4:
			sys.pMn1271->SoundDataCopy(2, 3);
			break;
		case WAIT_OBJECT_0 + 5:
		default:
			g_bSoundOn = false;
			_endthreadex(0);
			break;
		}
	}
	return 0L;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �u�ŋߎg�����t�@�C���v�̒ǉ��i���Ƀ��X�g�ɂ���t�@�C���͕��בւ��j
//
// mode : 0 = CJR,JR2 Set, 1 = Quick Load
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void AddRecentFiles(const TCHAR* str,  int mode)
{
	TCHAR tmpBuf[MAX_PATH];
	tmpBuf[0] = '\0';
	_tcscpy(tmpBuf, str);

	switch (mode)
	{
	case 0: // CJR,JR2 Set
		for (unsigned int i = 0; i < g_rFilesforCJRSet.size(); ++i) {
			if (_tcscmp(g_rFilesforCJRSet[i].data(), tmpBuf) == 0) {
				g_rFilesforCJRSet.erase(g_rFilesforCJRSet.begin() + i);
			}
		}
		g_rFilesforCJRSet.push_front(tmpBuf);
		if (g_rFilesforCJRSet.size() >= RECENT_FILES_NUM + 1) 
			while (g_rFilesforCJRSet.size() > RECENT_FILES_NUM) g_rFilesforCJRSet.pop_back();
		break;
	case 1: // Quick Load
		for (unsigned int i = 0; i < g_rFilesforQLoad.size(); ++i) {
			if (_tcscmp(g_rFilesforQLoad[i].data(), tmpBuf) == 0) {
				g_rFilesforQLoad.erase(g_rFilesforQLoad.begin() + i);
			}
		}
		g_rFilesforQLoad.push_front(tmpBuf);
		if (g_rFilesforQLoad.size() >= RECENT_FILES_NUM + 1) 
			while (g_rFilesforQLoad.size() > RECENT_FILES_NUM) g_rFilesforQLoad.pop_back();
		break;
	}

	SetMenuItemForRecentFiles();
}


////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �u�ŋߎg�����t�@�C���v�����j���[�ɔ��f
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void SetMenuItemForRecentFiles()
{
	HMENU hMenu, hFileMenu, hRecentFileMenu;
	MENUITEMINFO mii;
	TCHAR buf[MAX_PATH] = {};
	hMenu = GetMenu(g_hMainWnd);
	hFileMenu = GetSubMenu(hMenu, 0);
	hRecentFileMenu = GetSubMenu(hFileMenu, SUBMENU_POS);

	for (unsigned int i = 0; i < g_rFilesforCJRSet.size(); ++i) {
		TCHAR* fname;
		fname = PathFindFileName(g_rFilesforCJRSet[i].data());
		mii.dwTypeData = buf;
		mii.cbSize = sizeof(MENUITEMINFO);
		mii.fMask = MIIM_STATE;
		GetMenuItemInfo(hRecentFileMenu, IDM_FILE_RFILES_SETCJR0 + i, FALSE, &mii);

		mii.fMask = MIIM_STRING;
		int idx = i + 1;
		if (idx == 10) idx = 0;

		if (_tcslen(fname) == 0) {
			wsprintf(buf, _T("&%d.%s\tCtrl+Alt+%d"), idx, _T("-----"), idx);
		}
		else {
			wsprintf(buf, _T("&%d.%s\tCtrl+Alt+%d"), idx, fname, idx);
		}
		mii.dwTypeData = buf;
		SetMenuItemInfo(hRecentFileMenu, IDM_FILE_RFILES_SETCJR0 + i, FALSE, &mii);
		ZeroMemory(&mii, sizeof(mii));
	}

	for (unsigned int i = 0; i < g_rFilesforQLoad.size(); ++i) {
		TCHAR* fname;
		TCHAR head_array[] = _T("abcdefghij");
		TCHAR head[] = _T("a");
		fname = PathFindFileName(g_rFilesforQLoad[i].data());
		mii.dwTypeData = buf;
		mii.cbSize = sizeof(MENUITEMINFO);
		mii.fMask = MIIM_STATE;
		GetMenuItemInfo(hRecentFileMenu, IDM_FILE_RFILES_QLOAD0 + i, FALSE, &mii);

		mii.fMask = MIIM_STRING;
		int idx = i + 1;
		if (idx == 10) idx = 0;

		head[0] = head_array[i];
		if (_tcslen(fname) == 0) {
			wsprintf(buf, _T("&%s.%s\tShift+Alt+%d"), head, _T("-----"), idx);
		}
		else {
			wsprintf(buf, _T("&%s.%s\tShift+Alt+%d"), head, fname, idx);
		}
		mii.dwTypeData = buf;
		SetMenuItemInfo(hRecentFileMenu, IDM_FILE_RFILES_QLOAD0 + i, FALSE, &mii);
		ZeroMemory(&mii, sizeof(mii));
	}

	DrawMenuBar(g_hMainWnd);
}



////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR, JR2�t�H�[�}�b�g�̔���
//
// 0:�G���[�@�@1:CJR�@�@2:JR2
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int CheckFileFormat(const TCHAR* fileName)
{
	int ret = 0;
	FILE* fp;
	uint32_t fileSize;
	char buf[4];

	struct _stat stbuf;
	int st = _tstat(fileName, &stbuf);
	if (st != 0) return 0;
	fileSize = stbuf.st_size;

	TCHAR chkStr[MAX_PATH];
	_tcscpy(chkStr, fileName);
	_tcsupr(chkStr);
	if (_tcsncmp(_tcsrev(chkStr), _T("RJC."), 3) == 0) {
		if (fileSize >= CJR_FILE_MAX) return 0;
		fp = _tfopen(fileName, _T("rb"));
		if (fp == nullptr)
			return ret;
		fread(buf, sizeof(uint8_t), 2, fp);
		fclose(fp);
		char head[] = {0x2, 0x2a};
		if (!strncmp(buf, head, 2))
			ret = 1;
	}
	else if (_tcsncmp(chkStr, _T("2RJ."), 3) == 0) {
		fp = _tfopen(fileName, _T("rb"));
		if (fp == nullptr)
			return ret;
		fread(buf, sizeof(uint8_t), 3, fp);
		fclose(fp);
		const char* head = "JR2";
		if (!strncmp(buf, head, 3))
			ret = 2;
	}

	return ret;
}



////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �e�[�v�t�@�C�����}�E���g
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void MountTapeFile(const TCHAR* strFile, int type)
{
	if (type == 1) {
		// CJR����
		if (g_pTapeFormat != nullptr) {
			delete g_pTapeFormat;
			g_pTapeFormat = nullptr;
		}
		g_pTapeFormat = new CjrFormat();
		if (!g_pTapeFormat->Init(strFile))
			MessageBox(g_hMainWnd, g_stringTable[23], NULL, 0);
	}
	else if (type == 2) {
		// JR2����
		if (g_pTapeFormat != nullptr) {
			delete g_pTapeFormat;
			g_pTapeFormat = nullptr;
		}
		g_pTapeFormat = new Jr2Format();
		if (!g_pTapeFormat->Init(strFile))
			MessageBox(g_hMainWnd, g_stringTable[23], NULL, 0);
	}

}
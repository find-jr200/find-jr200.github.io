// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __JRSYSTEM_H__
#define __JRSYSTEM_H__
#include "Crtc.h"
#include "Address.h"
#include "Mn1271.h"
#include "Mn1544.h"
#include "m6800.h"

class JRSystem
{
public:
	JRSystem();
	~JRSystem();
	int Init();
	void Dispose();
	void Start();
	void Reset();
	void StepRun();
	Address* pAddress;
	Crtc* pCrtc;
	Mn1271* pMn1271;
	Mn1544* pMn1544;
	m6800_cpu_device* pCpu;

protected:
	int step;
};

#endif
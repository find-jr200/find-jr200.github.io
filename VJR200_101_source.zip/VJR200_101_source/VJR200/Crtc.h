// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __CRTC_H__
#define __CRTC_H__
#include <cstdint>
#ifdef _WIN32
#include <atlbase.h>
#include <d2d1.h>
#include <dwrite.h>
#endif
#include "Address.h"

#pragma comment(lib,"d2d1.lib")

#ifdef _WIN32
template<class Interface>
inline void SafeRelease(
	Interface **ppInterfaceToRelease
)
{
	if (*ppInterfaceToRelease != NULL)
	{
		(*ppInterfaceToRelease)->Release();
		(*ppInterfaceToRelease) = NULL;
	}
}
#endif

extern const int BITMAP_W;
extern const int BITMAP_H;

class Crtc
{
public:
	Crtc();
	~Crtc();
	bool Init();
	uint8_t Read(int r);
	void Write(int r, uint8_t b);
	void DiscardDeviceResources();
	void Resize(bool bFullScreen);
#ifdef _WIN32
	HRESULT OnRender();
#else
	void OnRender(uint32_t*  s);
#endif
	void TickCounter(int cycles);

protected:
	static const uint16_t PCGRAM1 = 0xc000;
	static const uint16_t TVRAM = 0xc100;
	static const uint16_t PCGRAM2 = 0xc400;
	static const uint16_t AVRAM = 0xc500;
	static const uint16_t FRAM = 0xd000;

	static const int COUNTER_WIDTH = 50;
	static const int CMTSTAT_WIDTH = 40;

	uint32_t JrColor[8];
	uint8_t borderColor = 0;
	uint32_t* pixelData;
	void SetPixelData();

#ifdef _WIN32
	ID2D1Factory* pD2dFactory = nullptr;
	IDWriteFactory* pDWriteFactory = nullptr;
	IDWriteTextFormat* pTextFormatL = nullptr;
	IDWriteTextFormat* pTextFormatR = nullptr;
	ID2D1HwndRenderTarget* pHwndRT = nullptr;
	ID2D1Bitmap* pBitmap = nullptr;
	ID2D1SolidColorBrush *pGrayBrush = nullptr;
	ID2D1SolidColorBrush *pBlackBrush = nullptr;

	HRESULT CreateDeviceResources();
	HRESULT CreateDeviceIndependentResources(); 
#endif

	bool bFullScreen = false;
	uint8_t getVal = 0;
};

#endif
// license:BSD-3-Clause
// copyright-holders:FIND
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class CjrFormat
// CJR�t�@�C���t�H�[�}�b�g�̑���S��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
// #include <assert.h>
#include <vector>
#include <sys/stat.h>
#include "CjrFormat.h"
#include "Address.h"
#include "JRSystem.h"

using namespace std;

extern JRSystem sys;

CjrFormat::CjrFormat()
{
	for (int i = 0; i < 136; ++i) // 136
	{
		leaderData.push_back(0xff);
	}

	for (int i = 0; i < 12; ++i) // 12
	{
		intermData.push_back(0xff);
	}

	pLoadData = new uint8_t[5000000]; // �Ȃ�ƂȂ�5MB�m��
}


CjrFormat::~CjrFormat()
{
	for (unsigned int i = 0; i < loadDataBlock.size(); ++i) {
		if (loadDataBlock[i] != nullptr) delete loadDataBlock[i];
	}

	delete pLoadData;

	if (fp != nullptr)
		fclose(fp);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJRFormat�N���X��CJR�f�[�^���Z�b�g
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::SetCjrData(uint8_t* d, int size)
{
	cjrData.assign(d, d + size);
	startAddress = cjrData[37] << 8;
	startAddress += cjrData[38];
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �{�[���[�g��ݒ肵�`�F�b�N�T�����ύX
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::AdjustBaudRate(int d)
{
	cjrData[23] = d;
	int sum = 0;

	for (int i = 0; i < 32; ++i) sum += cjrData[i];
	cjrData[32] = static_cast<uint8_t>(sum);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�f�[�^����BIN�𔲂��o���ĕԂ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t* CjrFormat::GetBinDataArray()
{
	int blockSize = 0;
	int currentPoint = 0;

	if (cjrData.size() == 0) return nullptr;

	// �w�b�_�ǂݔ�΂�
	currentPoint = 6 + cjrData[3] + 1;
	// �f�[�^�u���b�N�E�t�b�^�u���b�N�ǂݏo��
	while (cjrData[currentPoint + 2] != static_cast<uint8_t>(0xff))
	{
		blockSize = cjrData[currentPoint + 3] == 0 ? 256 : cjrData[currentPoint + 3];
		currentPoint += 6;
		for (int i = 0; i < blockSize; ++i)
		{
			binData.push_back(static_cast<uint8_t>(cjrData[currentPoint++]));
		}
		++currentPoint;
	}

	return binData.data();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// BIN�f�[�^�̃T�C�Y��Ԃ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int CjrFormat::GetBinSize()
{
	return binData.size();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�f�[�^�̃T�C�Y��Ԃ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int CjrFormat::GetCjrSize()
{
	return cjrData.size();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�f�[�^��BASIC�Ȃ�true�A�}�V����Ȃ�false��Ԃ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
bool CjrFormat::isBasic()
{
	if (cjrData.size() != 0) {
		if (cjrData[22] == 0)
			return true;
		else 
			return false;
	}
	else {
		assert(false);
		return 0;
	}

}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�̃��[�h�X�^�[�g�A�h���X��Ԃ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int CjrFormat::GetStartAddress()
{
	return startAddress;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// BIN�f�[�^����CJR�ɕϊ����ĕԂ�
//
// ����:jrFileName JR�p�̃t�@�C�����@�@startAddress ���[�h�X�^�[�g�A�h���X�@�@basic BASIC�Ȃ�true�A�}�V����Ȃ�false
//
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t* CjrFormat::GetCjrDataArray(char* jrFileName, int startAddress, bool basic)
{
	int blockCount = 0, checkSum = 0, pointer = 0, blockHead = 0;

	if (binData.size() == 0) return nullptr;

	if (basic) startAddress = 0x801;

	// �w�b�_�u���b�N
	cjrData.push_back(2);
	cjrData.push_back(0x2a);
	cjrData.push_back(static_cast<uint8_t>(blockCount));
	cjrData.push_back(0x1a);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	char n[16] = {0};
	strncpy(n, jrFileName, 16);
	for (int i = strlen(jrFileName); i < 16; ++i)
		n[i] = 0;
	cjrData.insert(cjrData.end(), n, n + 16); // �t�@�C����
	cjrData.push_back(static_cast<uint8_t>(basic ? 0 : 1)); // �}�V���� or BASIC
	cjrData.push_back(0); // �{�[���[�g

	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);

	for (uint16_t i = 0; i < cjrData.size(); ++i)
		checkSum += (int)cjrData[i];
	cjrData.push_back(static_cast<uint8_t>(checkSum));

	++blockCount;

	// �f�[�^�u���b�N
	while (true)
	{
		blockHead = cjrData.size();
		cjrData.push_back(2);
		cjrData.push_back(0x2a);
		cjrData.push_back(static_cast<uint8_t>(blockCount));
		cjrData.push_back(0); // �_�~�[�i�u���b�N�T�C�Y�j
		int sizePoint = cjrData.size() - 1;

		cjrData.push_back(static_cast<uint8_t>(startAddress >> 8));
		cjrData.push_back(static_cast<uint8_t>(startAddress & 0xff));

		int j;
		for (j = 0; j < 256; ++j)
		{
			cjrData.push_back(binData[pointer]);
			++pointer;
			if (pointer == binData.size()) break;
		}

		cjrData[sizePoint] = static_cast<uint8_t>((j == 256) ? 0 : j + 1);

		// �`�F�b�N�T���v�Z
		checkSum = 0;
		for (unsigned int i = blockHead; i < cjrData.size(); ++i)
			checkSum += (int)cjrData[i];
		cjrData.push_back(static_cast<uint8_t>(checkSum));

		++blockCount;
		startAddress += j;

		if (pointer == binData.size()) break;
	}

	// �t�b�^�u���b�N
	++startAddress;
	cjrData.push_back(2);
	cjrData.push_back(0x2a);
	cjrData.push_back(0xff);
	cjrData.push_back(0xff);
	cjrData.push_back(static_cast<uint8_t>(startAddress >> 8));
	cjrData.push_back(static_cast<uint8_t>(startAddress & 0xff));

	return cjrData.data();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�f�[�^��Ԃ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t * CjrFormat::GetCjrDataArray()
{
	return cjrData.data();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CJR�f�[�^�����[�h���邽�߂Ƀu���b�N���ƕ������Ă�loadDataBlock�ɒǉ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
bool CjrFormat::SetLoadDataBlock(int fileSize)
{
	if (cjrData.size() == 0) return false;

	AdjustBaudRate(0); //////////////////// 2400baud�ɐݒ�

	int c = 0, p = 0, blockNo, dataSize;
	loadDataBlock.push_back(new vector<uint8_t>());
	if (cjrData[2] == 0) {
		loadDataBlock[0]->insert(loadDataBlock[0]->end(), cjrData.begin(), cjrData.begin() + 33);
		p = 33;
		++c;
	}
	while ((blockNo = cjrData[p + 2]) < 0xff && p < fileSize) {
		dataSize = cjrData[p + 3];
		if (dataSize == 0) dataSize = 256;
		dataSize += 7;
		loadDataBlock.push_back(new vector<uint8_t>());
		loadDataBlock[c]->insert(loadDataBlock[c]->end(), &cjrData[p], &cjrData[p + dataSize]);
		p += dataSize;
		++c;
	}
	if (p >= fileSize) return false;

	loadDataBlock.push_back(new vector<uint8_t>());
	loadDataBlock[c]->insert(loadDataBlock[c]->end(), cjrData.end() - 6, cjrData.end());

	itBlock = loadDataBlock.begin();
	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ������loadData�Ƀ��[�h�p�̔g�`�f�[�^���i�[
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int CjrFormat::GetLoadData(uint8_t* loadData)
{
	bool isLeader = true;
	int p = 0;
	int count = 0;
	int sign = 1;

	while (itBlock != loadDataBlock.end())
	{
		if (isLeader) {
		// Leader, intermission
			if (count == 0) { // Leader
				for (unsigned int i = 0; i < leaderData.size(); ++i) {
					ByteGetter by(&leaderData);
					BitGetterL bi(by.Get());
					for (int k = 0; k < 8; ++k) { // 1�o�C�g�̃��[�v
						WaveGetter wg(bi.Get());
						for (int l = 0; l < 8; ++l) { // 1�r�b�g�̃��[�v
							int x = wg.Get(1, sign);
							*(loadData + p) = x;
							++p;
						}
					}
				}
			}
			else { // intermission
				for (unsigned int i = 0; i < intermData.size(); ++i) {
					ByteGetter by(&intermData);
					BitGetterL bi(by.Get());
					for (int k = 0; k < 8; ++k) { // 1�o�C�g�̃��[�v
						WaveGetter wg(bi.Get());
						for (int l = 0; l < 8; ++l) { // 1�r�b�g�̃��[�v
							int x = wg.Get(1, sign);
							*(loadData + p) = x;
							++p;
						}
					}
				}
			}
			isLeader = false;
		} else { // data��
			ByteGetter byteG(*itBlock);
			for (unsigned int i = 0; i < (*itBlock)->size(); ++i) { // 1�f�[�^�u���b�N�̃��[�v
				uint8_t bytedata = byteG.Get();
				BitGetterD bitG(bytedata);
				for (int k = 0; k < 12; ++k) { // 1�o�C�g�̃��[�v
					WaveGetter wg;
					wg.Set(bitG.Get());

					if (count == 0) { // �w�b�_�u���b�N�̂�600baud�Œ�
						for (int l = 0; l < 8; ++l) { // 1�r�b�g�̃��[�v
							*(loadData + p) = wg.Get(1, sign);
							++p;
						}
					}
					else {
						for (int l = 0; l < 2; ++l) { // 1�r�b�g�̃��[�v
							*(loadData + p) = wg.Get(0, sign);
							++p;
						}
					}
				}
			}
			isLeader = true;
			++itBlock;
			++count;
		}

		for (unsigned int i = 0; i < intermData.size(); ++i) {
			ByteGetter by(&intermData);
			BitGetterL bi(by.Get());
			for (int k = 0; k < 8; ++k) { // 1�o�C�g�̃��[�v
				WaveGetter wg(bi.Get());
				for (int l = 0; l < 8; ++l) { // 1�r�b�g�̃��[�v
					int x = wg.Get(1, sign);
					*(loadData + p) = x;
					++p;
				}
			}
		}
	}

	return p;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ��������Ԃ���BASIC���X�g��CJR�����ĕԂ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t* CjrFormat::MemToCjrBasic(char* jrFileName)
{
	uint16_t d;
	int nextAddress = 0, current = 0x801;
	Address* a = sys.pAddress;

	d = a->ReadByte(current++);
	while (d != 0)
	{
		binData.push_back((uint8_t)d);
		nextAddress = d << 8;
		d = a->ReadByte(current++);
		nextAddress += d;
		binData.push_back((uint8_t)d);

		for (int i = current; i < nextAddress; ++i) {
			binData.push_back(a->ReadByte(current++));
		}

		d = a->ReadByte(current++);
	}

	binData.push_back((uint8_t)d);
	binData.push_back(a->ReadByte(current++));
	binData.push_back(a->ReadByte(current++));

	return GetCjrDataArray(jrFileName, 0x801, true);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ��������Ԃ��������start����end�܂ł��}�V����CJR�ɂ��ĕԂ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t* CjrFormat::MemToCjrBin(char* jrFileName, int start, int end)
{
	Address* a = sys.pAddress;

	for (int i = start; i <= end; ++i) {
		binData.push_back(sys.pAddress->ReadByte(i));
	}
	return GetCjrDataArray(jrFileName, start, false);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////

bool CjrFormat::Init(const TCHAR * fn)
{
	_tcsncpy(fileName, fn, MAX_PATH);

	struct _stat buf;
	int st = _tstat(fileName, &buf);
	if (st != 0)
		return false;
	fileSize = buf.st_size;

	uint8_t binData[65536];
	fp = _tfopen(fileName, _T("rb"));
	if (fp == nullptr)
		return false;
	fread(binData, sizeof(uint8_t), fileSize, fp);
	fclose(fp);
	fp = nullptr;

	SetCjrData(binData, (int)fileSize);
	if (!SetLoadDataBlock(fileSize)) return false;
	loadDataSize = GetLoadData(pLoadData);
	pointer = 0;

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �^�C�v�𕶎���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
const TCHAR* CjrFormat::GetType()
{
	return _T("CJR");
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C������Ԃ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
const TCHAR* CjrFormat::GetFileName()
{
	return fileName;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 1�o�C�g��������
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::WriteByte(uint8_t b)
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// 1�r�b�g���̃��[�h�f�[�^��Ԃ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint8_t CjrFormat::GetLoadData()
{
	bCountStart = true;
	return *(pLoadData + pointer);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CPU�̏���N���b�N���J�E���^��i�߂�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::TickCounter(int c)
{
	if (!bCountStart) return;

	counter += c;
	if (counter >= DATA_CYCLE) {
		counter = 0;
		if (pointer <loadDataSize)
			++pointer;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu���o�C�g���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t CjrFormat::GetPoiner()
{
	return pointer;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu��b���ŕԂ�
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
uint32_t CjrFormat::GetTimeCounter()
{
	return pointer * 209 / 1000000;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �����[�g�[�q���^���E�Đ��ɂȂ������̏���
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::remoteOn()
{
	counter = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �����[�g�[�q����~�ɂȂ������̏���
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::remoteOff()
{
	bCountStart = false;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �t�@�C���ʒu��擪��
// 
////////////////////////////////////////////////////////////////////////////////////////////////////
void CjrFormat::Top()
{
	pointer = 0;
}

void CjrFormat::Next()
{
}

void CjrFormat::Prev()
{
}

void CjrFormat::FF()
{
}

void CjrFormat::Rew()
{
}

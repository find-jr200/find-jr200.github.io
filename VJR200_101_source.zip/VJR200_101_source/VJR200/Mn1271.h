// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __MN1271_H__
#define __MN1271_H__
#ifdef _WIN32
#include <MMSystem.h>
#include <dsound.h>
#endif
#include <cstdint>
#include <vector>
#include "VJR200.h"

using namespace std;

enum class Reg3 { KACK = 1, KTEST = 2, KSTROBE = 4, INIT = 8, BUSY = 16, PSEL = 32, KEYSOUND = 64, KSTAT = 128 };
enum class Reg9 { KON = 16, SYSINT = 32, USERINT = 64 };
enum class Reg0e { COUNT = 1, PRESCALE = 24, BORROW = 32, IRQ = 64 };
enum class RegSound8 { DATA = 7, PRESCALE = 24, BORROW = 32, IRQ = 64 };
enum class RegSound16 { DATA = 7, PRESCALE = 8, PULSE = 16, BORROW = 32, IRQ = 64 };
enum class Reg1c { PI0_STAT = 1, PI1_STAT = 2, PI2_STAT = 4, SERIAL_STAT = 64 };
enum class Reg1d { TCA_STAT = 1, TCB_STAT = 2, TCC_STAT = 4, TCD_STAT = 8, TCE_STAT = 16, TCF_STAT = 32 };
enum class Reg1e { PI0_MASK = 1, PI1_MASK = 2, PI2_MASK = 4, SERIAL_MASK = 64 };
enum class Reg1f { TCA_MASK = 1, TCB_MASK = 2, TCC_MASK = 4, TCD_MASK = 8, TCE_MASK = 16, TCF_MASK = 32 };
enum class IrqType { KON = 1, SYSINT = 2, USERINT = 4, SERIAL = 128, TCA = 512, TCB = 1024, TCC = 2048, TCD = 4096, TCE = 8192, TCF = 16384 };
enum class PrinterOutput {TEXT, RAW};
enum class PrinterMaker {PANASONIC, EPSON};

class Mn1271
{
public:
	Mn1271();
	~Mn1271();
	bool Init(void);
	void SetVolume(int vol);
	void SetPan(int ch, int vol);
	void TickTimerCounter(int cycles);
	uint8_t Read(uint8_t reg);
	uint8_t ReadforDebug(uint8_t r);
	void Write(uint8_t ret, uint8_t val);
	void AssertIrq(int type);
	vector<uint8_t>* saveData = nullptr;

	void SoundDataCopy(int ch, UINT n);
	void SetSoundData(int ch);
	void SoundOn();
	void SoundOff();
	void CheckStatus();
	bool GetRemoteStatus();
	bool GetReadStatus();
	bool GetWriteStatus();

	bool debugTcaEnable = true;
	bool debugTcbEnable = true;
	bool debugTccEnable = true;
	bool debugTcdEnable = true;
	bool debugTceEnable = true;
	bool debugTcfEnable = true;

protected:
	static const int SAMPLING_FREQUENCY = 44100;
	static const int BUFFER_BLOCK_NUM = 5;
	uint8_t reg[32] = {};
	uint8_t reg17WriteBuf = 0, reg1aWriteBuf = 0;
	uint8_t reg18ReadBuf = 0, reg1bReadBuf = 0;

	void SetIrqFlag();
	int GetPrescale(int i);

	void Reg3_write(uint8_t val);
	void Reg5_write(uint8_t val);
	void Reg7_write(uint8_t val);
	void Reg9_write(uint8_t val);
	void Reg0d_write(uint8_t val);
	void Reg0e_write(uint8_t val);
	void Reg10_write(uint8_t val);
	void Reg12_write(uint8_t val);
	void Reg14_write(uint8_t val);
	void Reg16_write(uint8_t val);
	void Reg19_write(uint8_t val);
	void Reg1e_write(uint8_t val);
	void Reg1f_write(uint8_t val);
	void SetIrqMask1(int bit, int value);
	void SetIrqMask2(int bit, int value);

	void Reg7_read();

	unsigned int tcaSetVal = 0;
	unsigned int tcbSetVal = 0;
	unsigned int tccSetVal = 0;
	unsigned int tcdSetVal = 0;
	unsigned int tceHSetVal = 0;
	unsigned int tceLSetVal = 0;
	unsigned int tcfHSetVal = 0;
	unsigned int tcfLSetVal = 0;

	int tcaCountEnable, tcbCountEnable, tceCountEnable;
	int tcaCycleCount, tcbCycleCount, tceCycleCount;

#ifdef _WIN32
	LPDIRECTSOUND8		pDS = nullptr;
	LPDIRECTSOUNDBUFFER	pPrimary = nullptr;
	LPDIRECTSOUNDBUFFER	pSecondary[3];
	LPDIRECTSOUNDNOTIFY8 pNotify[3];

	BOOL CreatePrimaryBuffer(void);
	BOOL CreateSoundBuffer(LPDIRECTSOUNDBUFFER *dsb);
#endif

	int loadDataSize;
	int loadPointer = 0;
	int borrowCount = 0;
	bool bSaving = false;

	int blockSize;
	int16_t GetWave(int ch);
	double SquareWave(int f, double t);
	void PlaySound(int ch);
	void StopSound(int ch);
	void SetFrequency(int ch, int f);
	bool bPlaying[3] = {};
	int frequency[3] = {};
	int wtPointer[3] = {};
	int preFreq[3] = {};

	bool bWrite = false;
	bool bRead = false;
	bool bRemoteOn = false;
	bool bEnterIrq = false;
	uint16_t suspendedIrq = 0;
};

#endif
// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __VJR200_H__
#define __VJR200_H__
#include <deque>
#include "resource.h"
#include "MemWindow.h"
#include "DisasmWindow.h"
#include "ITapeFormat.h"

using namespace std;

extern const int CLOCK;
extern const int BITMAP_W;
extern const int BITMAP_H;
extern const float REAL_WRATIO;
extern const int STR_RESOURCE_NUM;
extern const unsigned int RECENT_FILES_NUM;
extern const int STATUSBAR_HEIGHT;
extern const int SUBMENU_POS;
extern const int CJR_FILE_MAX;

extern HINSTANCE g_hInst;
extern TCHAR szTitle[];                  // �^�C�g�� �o�[�̃e�L�X�g
extern TCHAR szWindowClass[];            // ���C�� �E�B���h�E �N���X��
extern HWND g_hMainWnd;
extern HWND g_hMemWnd;
extern HMODULE g_hMod;
extern int g_debug;
extern int g_breakPoint;
extern bool g_bSoundOn;
extern bool g_bMemWindow;
extern bool g_bDisasmWindow;
extern MemWindow* g_pMemWindow;
extern DisasmWindow* g_pDisasmWindow;
extern HANDLE g_hEvent[][6];
extern TCHAR g_stringTable[][256];
extern int g_dramWait;
extern bool g_deviceRunning;
extern uint8_t g_gcharCode1[][14];
extern uint8_t g_gcharCode2[][14];
extern BYTE g_bits1[], g_bits2[];
extern int g_vcyncCounter;
extern ITapeFormat* g_pTapeFormat;


extern int g_cpuScale;
extern int g_viewScale;
extern bool g_bSmoothing;
extern bool g_bFpsCpu;
extern int g_soundVolume;
extern bool g_bRamExpand1;
extern bool g_bRamExpand2;
extern RECT g_windowPos;
extern TCHAR g_pRomFile[];
extern TCHAR g_pFontFile[];
extern deque<wstring> g_rFilesforCJRSet;
extern deque<wstring> g_rFilesforQLoad;
extern int g_refRate;
extern bool g_bRefRateAuto;
extern bool g_bSquarePixel;
extern bool g_bOverClockLoad;
extern int g_quickTypeS;
extern int g_language;
extern int g_stereo1, g_stereo2, g_stereo3;
extern int g_prOutput;
extern int g_prMaker;
extern bool g_b2buttons;
extern int g_Joypad1pA, g_Joypad1pB, g_Joypad2pA, g_Joypad2pB;
extern int g_forcedJoypadA, g_forcedJoypadB; 
extern bool bForcedJoystick;
extern int g_sBufferWriteInterval;
extern int g_bCmtAddBlank;


ATOM                MyRegisterClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);
BOOL OpenFileDialog(TCHAR * filter, TCHAR * fileName, HWND hwnd);
BOOL CALLBACK DlgSaveCjrProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void ChangeWindowSize(HMENU hMenu);
void SetMenuItemState(HMENU hMenu);
int GetRefreshRate();
BOOL CALLBACK DlgVGraphKeybProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
BOOL CALLBACK DlgOptionProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DlgDebugProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp);
BOOL CALLBACK DlgRomFontProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
VOID CALLBACK FpsTimerRoutine(PVOID lpParam, BOOLEAN TimerOrWaitFired);
VOID CALLBACK QuicTypeTimerRoutine(PVOID lpParam, BOOLEAN TimerOrWaitFired);
bool CreateSoundThreads();
DWORD WINAPI SoundSetThread0(LPVOID param);
DWORD WINAPI SoundSetThread1(LPVOID param);
DWORD WINAPI SoundSetThread2(LPVOID param);
void AddRecentFiles(const TCHAR* str, int mode);
void SetMenuItemForRecentFiles();
int CheckFileFormat(const TCHAR* fileName);
void MountTapeFile(const TCHAR* strFile, int type);

#endif

// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __SERIALIZE_GLOBAL_H__
#define __SERIALIZE_GLOBAL_H__
#include <cereal/cereal.hpp>

class SerializeGlobal
{
	int dramWait, cpuScale;
	bool bSoundOn;

public:
	template<class Archive>
	inline void save(Archive & ar, std::uint32_t const version) const
	{
		ar(g_cpuScale, g_dramWait, g_bSoundOn);
	}

	template<class Archive>
	inline void load(Archive & ar, std::uint32_t const version)
	{
		ar(cpuScale, dramWait, bSoundOn);
		g_cpuScale = cpuScale;
		g_dramWait = dramWait;
		g_bSoundOn = bSoundOn;
	}
};

CEREAL_CLASS_VERSION(SerializeGlobal, CEREAL_VER);

#endif
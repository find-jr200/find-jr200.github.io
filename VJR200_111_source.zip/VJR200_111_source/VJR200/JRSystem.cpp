// license:BSD-3-Clause
// copyright-holders:FIND
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class JRSystem
// JR-200�G�~�����[�g�ɕK�v�ȃN���X���Ǘ�����N���X
//
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "JRSystem.h"
#include "VJR200.h"

JRSystem::JRSystem()
{
}


JRSystem::~JRSystem()
{
	Dispose();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ������
//
////////////////////////////////////////////////////////////////////////////////////////////////////
int JRSystem::Init()
{
	int ret = 0;

	pAddress = new Address;
	if (pAddress->Init() == false) {
		Dispose();
		return 1;
	}
	pCrtc = new Crtc;
	if (pCrtc->Init() == false) {
		Dispose();
		return 2;
	}
	pMn1544 = new Mn1544;
	if (pMn1544->Init() == false) {
		Dispose();
		return 3;
	};

	pMn1271 = new Mn1271;
	if (pMn1271->Init() == false) {
		Dispose();
		return 4;
	}

	switch (g_prOutput) {
	case (int)PrinterOutput::TEXT:
		pPrinter = new TextPrinter;
		if (pPrinter->Init() == false) {
			Dispose();
			return 5;
		}
		break;
	case (int)PrinterOutput::RAW:
		pPrinter = new RawPrinter;
		if (pPrinter->Init() == false) {
			Dispose();
			return 6;
		}
		break;
	case (int)PrinterOutput::PNG:
		pPrinter = new ImagePrinter;
		if (pPrinter->Init() == false) {
			Dispose();
			return 7;
		}
	}


	pCpu = new m6800_cpu_device;

	if (_tcslen(g_pRomFile) == 0) {
		g_deviceRunning = false;
	}
	else {
		g_deviceRunning = true;
	}

	if (_tcslen(g_pFontFile) == 0) {
		g_deviceRunning = false;
	}
	else {
		g_deviceRunning = true;
	}

	if (!pAddress->LoadRomFile())
		g_deviceRunning = false;

	g_cpuScale = 100;

	return ret;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// JRSystem���Ő��������N���X��delete
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void JRSystem::Dispose()
{
	if (pCpu != nullptr) {
		delete pCpu;
		pCpu = nullptr;
	}
	if (pMn1271 != nullptr) {
		delete pMn1271;
		pMn1271 = nullptr;
	}
	if (pMn1544 != nullptr) {
		delete pMn1544;
		pMn1544 = nullptr;
	}
	if (pCrtc != nullptr) {
		delete pCrtc;
		pCrtc = nullptr;
	}
	if (pAddress != nullptr) {
		delete pAddress;
		pAddress = nullptr;
	}
	if (pPrinter != nullptr) {
		delete pPrinter;
		pPrinter = nullptr;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// CPU���Z�b�g
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void JRSystem::Reset()
{
	if (g_pTapeFormat != nullptr) {
		delete g_pTapeFormat;
		g_pTapeFormat = nullptr;
	}

	pCpu->device_start();
	pCpu->device_reset();
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// JR-200�R�[�h���s
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void JRSystem::StepRun()
{
	step = (int)(CLOCK * g_cpuScale * 0.01f / g_refRate);
	switch (g_debug)
	{
	case -1:// -1 = �ʏ���s
		pCpu->run(step);
		break;
	case 0:// 0 = ��~

		break;
	case 1:// 1 = �X�e�b�v���s
		pCpu->run(1);
		g_debug = 0;
		break;
	}
}


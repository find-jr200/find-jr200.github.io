// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __ANALYZEWAVE_H__
#define __ANALYZEWAVE_H__
#include <cstdint>
#include <vector>
#include <math.h>
using namespace std;

enum BaudRate { LOW, HIGH };

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class CjrParameter
// 
// �萔�̂�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
class CjrParameter
{
public:
	static const int lowFreqSpan = 2;
	static const int hiFreqSpan = 1;
	static const int maxSpan = 2;
	static const int minSpan = 1;
	static const int LOW_F = 1200;
	static const int HIGH_F = 2400;
};

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class BaudParameter
// 
// baudrate�ɂ���ĕK�v�ȃT�C�N����ݒ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
class BaudParameter
{
public:
	int hiCycle;
	int lowCycle;

	void SetBaudRate(BaudRate b)
	{
		if (b == LOW)
		{
			hiCycle = 8;
			lowCycle = 4;
		}
		else
		{
			hiCycle = 2;
			lowCycle = 1;
		}
	}
};

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class WaveState
// 
// Wav����͂��f�[�^�ɕϊ����邽�߂̏�Ԃ�ێ�
//
////////////////////////////////////////////////////////////////////////////////////////////////////
class WaveState
{
public:
	bool PlusClear;
	bool MinusClear;
	bool TurnOver = false;

	void SetState(int data)
	{
		if (data > max) max = data;
		if (data < min) min = data;
		if (data >= 0) sign = 1; else if (data < 0) sign = -1; // �f�[�^���[���̏ꍇ�͐��ɂ��Ă���
		if (data > threshold) PlusClear = true;
		if (data < threshold * -1) MinusClear = true;
		if (sign * lastSign < 0) TurnOver = true;
		else TurnOver = false;

		lastData = data;
		lastSign = sign;
	}

protected:
	int max = 0;
	int min = 0;
	int sign = 0;
	int lastSign = 0;
	int lastData = 0;
	int threshold = 64;
};



class AnalyzeWave
{
public:
	AnalyzeWave(vector<uint8_t>*);
	~AnalyzeWave();
	bool AnalyzeWavData();
	void WriteCjrFile();


protected:
	vector<uint8_t>* saveData; // JR�������o�����f�[�^
	vector<int8_t> convertedList; // saveData�������₷���ϊ�
	vector<uint8_t> cjrList; // ���ʂ�CJR
	int bitData[8];
	WaveState wState;
	int readBytes = 0;
	long checkSum = 0;
	int blockCount = 0;
	int lastData = 0;
	bool bWaveOn = false;
	uint8_t blockHead[3]; // �u���b�N�擪�� 02, 2a, xx �̕���
	int dataCount;
	BaudParameter bparam;
	CjrParameter param;
	unsigned int readCount = 0;

	int GetSample();
	int GetHalfSpan();
	int BitToByte(int* BitData);
	void SetConvertedList();

};

#endif
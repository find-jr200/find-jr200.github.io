// license:BSD-3-Clause
// copyright-holders:FIND
////////////////////////////////////////////////////////////////////////////////////////////////////
//
// class Printer
// �v�����^���N���X
//
////////////////////////////////////////////////////////////////////////////////////////////////////
#include "stdafx.h"
#include "VJR200.h"
#include "Printer.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �v�����^�f�[�^�A�C�R����_��
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void Printer::DataActive()
{
	DrawPrinterIcon(true);
	bCountOn = true;
	count = 0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// �v�����^�f�[�^�A�C�R���̓_�����Ԃ��Ǘ�����J�E���^
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void Printer::CountUp()
{
	if (!bCountOn) return;

	count += (float)1 / g_refRate;
	if (count > LEDON_TIME) {
		DrawPrinterIcon(false);
		Finish(false);
		count = 0;
		bCountOn = false;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ���j���[�o�[��Ƀv�����^�f�[�^�A�C�R����\��
//
// �����@bActive = true �Ȃ�f�[�^��M���
//
////////////////////////////////////////////////////////////////////////////////////////////////////
void Printer::DrawPrinterIcon(bool bActive)
{
	int bmpSize = 16;
	int cyTitleBar = GetSystemMetrics(SM_CYCAPTION);
	int cxFrame = GetSystemMetrics(SM_CXFRAME);
	int cyFrame = GetSystemMetrics(SM_CYFRAME);
	RECT rcWnd;
	GetWindowRect(g_hMainWnd, &rcWnd);

	HDC	hdc = GetWindowDC(g_hMainWnd);
	HDC hdcMem = CreateCompatibleDC(hdc);
	HGDIOBJ	hold;
	if (bActive)
		hold = SelectObject(hdcMem, bmpLedActive);
	else
		hold = SelectObject(hdcMem, bmpLedInactive);

	BitBlt(hdc, rcWnd.right - rcWnd.left - cxFrame * 2 - bmpSize - 1, cyTitleBar + cyFrame * 2 + 1, bmpSize, bmpSize, hdcMem, 0, 0, SRCCOPY);
	SelectObject(hdcMem, hold);
	DeleteDC(hdcMem);
	ReleaseDC(g_hMainWnd, hdc);
}


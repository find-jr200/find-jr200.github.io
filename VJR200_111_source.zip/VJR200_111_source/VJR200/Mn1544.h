// license:BSD-3-Clause
// copyright-holders:FIND
#ifndef __MN1544_H__
#define __MN1544_H__
#include <cstdint>

enum class InputType {ANK, KANA, GRAPH};

class Mn1544
{
public:
	static const int FONTSIZE = 2048;
	Mn1544();
	~Mn1544();
	void SetKeyState(uint8_t reg);
	bool Init();
	void TickCounter(int cycles);
	void StartQuickType(TCHAR* data);
	void StopQuickType();
	uint8_t KeyIn(int w, int l);
	uint8_t KeyScan();
	uint8_t ConvertKeyCode(int w);
	uint8_t fontData[FONTSIZE + 1];
	bool bQuickType = false;

protected:
	void ScanKeyAndPad();
	void AutoType(const char w[]);

	uint8_t scanBuff[3];
	int pointer = 0;
	bool joystick1 = false;
	bool joystick2 = false;
	InputType mode = InputType::ANK;
	bool bInitialized = false;
	bool bScaned = false;
	bool bScanning = false;
	bool bKtested = false;
	bool bBreakOn = true;
	bool bKeyRepeat = false;

	uint8_t preKtest = 0;
	uint8_t preKack = 0;
	uint8_t prepreKtest = 0;
	uint8_t prepreKack = 0;

	bool bAutoTyping = false;
	double counter = 0, interval;
	uint8_t* typeWord = nullptr;
	int wordLen, typeCount;
	int preCpuScale;
};

#endif